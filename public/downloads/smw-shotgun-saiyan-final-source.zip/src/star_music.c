/* Four-voice pulse/triangle/noise chiptune arrangement for star power. */
#include "star_music.h"
#include "smw_rtl.h"
#include "variables.h"
#include <math.h>
#include <string.h>
#include "star_theme_notes.h"
static struct {double phase,end,start,hz;int note,velocity;} voices[4];
static double clock_ms;
static unsigned cursor,noise=0x2151a8e;
static int previous_star;
bool StarMusicActive(void){return misc_game_mode==0x14 && timer_star_power && player_current_state!=9;}
static void Restart(void){clock_ms=0;cursor=0;memset(voices,0,sizeof(voices));}
void StarMusicMix(int16 *samples,int frames,int channels,int rate){
  int star=timer_star_power;
  if(!StarMusicActive()){Restart();previous_star=0;return;}
  if(!previous_star || star>previous_star+1)Restart();
  previous_star=star;
  if(flag_pause || rate<=0)return;
  for(int i=0;i<frames;++i){
    if(clock_ms>=kThemeLoopMs)Restart();
    while(cursor<sizeof(kThemeNotes)/sizeof(kThemeNotes[0]) && kThemeNotes[cursor].start<=clock_ms){
      const struct ThemeNote *n=&kThemeNotes[cursor++];int v=n->voice;
      voices[v].start=n->start;voices[v].end=n->start+n->length;voices[v].note=n->note;
      voices[v].velocity=n->velocity;voices[v].hz=440*pow(2,(n->note-69)/12.0);voices[v].phase=0;
    }
    double mix[2]={0,0};
    for(int v=0;v<4;++v){
      if(clock_ms>=voices[v].end)continue;
      double age=(clock_ms-voices[v].start)/1000,remaining=(voices[v].end-clock_ms)/1000;
      double env=fmin(1,age/0.004)*fmin(1,remaining/0.012),p=voices[v].phase,value;
      if(v==0)value=(p<0.5?1:-1)*3800;
      else if(v==1)value=(4*fabs(p-0.5)-1)*2600;
      else if(v==2)value=(p<0.25?1:-0.333333)*1400;
      else{
        noise^=noise<<13;noise^=noise>>17;noise^=noise<<5;
        double n=((int)(noise&65535)-32768)/32768.0;
        if(voices[v].note==36||voices[v].note==35)value=sin(6.28318530718*(65*age+2.5*(1-exp(-age*35))))*2600*exp(-age*25);
        else value=n*(voices[v].note>=42?650:1500)*exp(-age*(voices[v].note>=42?65:30));
        env=fmin(1,age/0.001);
      }
      value*=env*voices[v].velocity/127.0;
      mix[0]+=value*(v==2?1.0:0.92);mix[1]+=value*(v==2?0.65:0.92);
      voices[v].phase+=voices[v].hz/rate;voices[v].phase-=floor(voices[v].phase);
    }
    for(int ch=0;ch<channels;++ch){int value=samples[i*channels+ch]+(int)mix[ch&1];
      samples[i*channels+ch]=value>32767?32767:value<-32768?-32768:value;}
    clock_ms+=1000.0/rate;
  }
}
