#define SMW_CAPTURE_MAIN
#include "headless.c"
#include "src/music_layer.h"
#include "src/snes/dsp.h"
static long Energy(const int16 *p,int n){long e=0;for(int i=0;i<n;++i)e+=abs(p[i]);return e;}
static long NativeDifference(const int16 *p,int frames){
  long e=0;double at=0,step=534.0/frames;
  for(int i=0;i<frames;++i,at+=step)for(int ch=0;ch<2;++ch)
    e+=abs(p[i*2+ch]-g_spc_player->dsp->sampleBuffer[(int)at*2+ch]);
  return e;
}

static double ToneEnergy(const int16 *pcm, int begin, int count, double hz){
  double real=0,imaginary=0;
  for(int i=0;i<count;++i){
    double window=0.5-0.5*cos(6.283185307179586*i/(count-1));
    double value=pcm[(begin+i)*2]*window;
    double phase=6.283185307179586*hz*i/32000;
    real+=value*cos(phase);imaginary+=value*sin(phase);
  }
  return real*real+imaginary*imaginary;
}
static void ElectricLeadTests(const char *dir){
  MusicLayer layer;MusicLayer_Reset(&layer);
  MusicLayer_NoteOn(&layer,0,72,0.9,0.25);
  MusicLayer_NoteOn(&layer,2,43,0.8,0.25);
  MusicLayer_SetMode(&layer,1);
  unsigned chords=layer.guitar.notes,leads=layer.lead.notes;
  MusicLayer_NoteOn(&layer,0,76,0.9,0.25);
  assert(layer.lead.notes>leads && layer.lead.last_midi==76);
  assert(layer.guitar.notes==chords && layer.guitar.root_midi==43);
  leads=layer.lead.notes;MusicLayer_NoteOn(&layer,2,48,0.8,0.25);
  assert(layer.lead.notes==leads && layer.lead.last_midi==76);

  LeadGuitar lead;LeadGuitar_Reset(&lead);
  LeadGuitar_NoteOn(&lead,0,72,1);LeadGuitar_SetEnabled(&lead,true);
  int16 pcm[24000*2];
  for(int i=0;i<24000;++i){
    if(i==16000)LeadGuitar_KeyOff(&lead,1);
    double sample[2];LeadGuitar_Sample(&lead,sample);
    pcm[i*2]=sample[0];pcm[i*2+1]=sample[1];
  }
  double fundamental=ToneEnergy(pcm,1024,8192,523.25113);
  assert(fundamental>3*ToneEnergy(pcm,1024,8192,493.88330));
  assert(fundamental>3*ToneEnergy(pcm,1024,8192,554.36526));
  assert(Energy(pcm,32000)>100000);
  assert(Energy(pcm+46000,2000)<100);
  char path[4096];snprintf(path,sizeof(path),"%s/00-isolated-electric-lead.s16le",dir);
  FILE *f=fopen(path,"wb");assert(f);assert(fwrite(pcm,sizeof(pcm),1,f)==1);fclose(f);
  LeadGuitar_SetEnabled(&lead,false);
  double sample[2];LeadGuitar_Sample(&lead,sample);assert(!sample[0] && !sample[1]);
  puts("PASS: distorted electric lead plays the melody at the correct pitch, releases cleanly and stays independent of low power chords");
}

static void PowerChordTests(const char *dir){
  MusicLayer layer;MusicLayer_Reset(&layer);
  MusicLayer_NoteOn(&layer,0,76,0.8,0.18); /* melody */
  MusicLayer_NoteOn(&layer,2,43,0.8,0.25); /* bass */
  MusicLayer_SetMode(&layer,1);
  assert(layer.guitar.source_channel==2 && layer.guitar.root_midi==43);
  unsigned picks=layer.guitar.notes;
  MusicLayer_NoteOn(&layer,0,79,0.8,0.18);
  assert(layer.guitar.notes==picks && layer.guitar.root_midi==43);
  MusicLayer_Sample(&layer,0);
  MusicLayer_NoteOn(&layer,2,48,0.8,0.12);
  assert(layer.guitar.root_midi==36 && layer.guitar.notes>picks);
  for(int n=24;n<100;++n){MusicLayer_NoteOn(&layer,2,n,0.8,0.12);
    assert(layer.guitar.root_midi>=35 && layer.guitar.root_midi<=46);MusicLayer_Sample(&layer,0);}
  MusicLayer_Reset(&layer);MusicLayer_NoteOn(&layer,2,38,1,0.5);MusicLayer_SetMode(&layer,1);
  char path[4096];snprintf(path,sizeof(path),"%s/00-isolated-low-power-chord.s16le",dir);
  FILE *f=fopen(path,"wb");assert(f);
  for(int block=0;block<42;++block){for(int i=0;i<534;++i)MusicLayer_Sample(&layer,i);
    int16 pcm[1068]={0};MusicLayer_Mix(&layer,pcm,534);assert(fwrite(pcm,sizeof(pcm),1,f)==1);}
  fclose(f);puts("PASS: low recorded power chord follows bass, ignores lead changes, stays in B1-Bb2 register");
}
static long Phrase(const char *dir,const char *name,int frames,bool layered){
  char path[4096];snprintf(path,sizeof(path),"%s/%s.s16le",dir,name);
  FILE *f=fopen(path,"wb");assert(f);long difference=0,energy=0;
  for(int n=0;n<frames;++n){
    RtlRunFrame(1u<<30);
    int16 pcm[534*2];RtlRenderAudio(pcm,534,2);
    if(SmwSpcPlayer_MusicLayerMode(g_spc_player)==1){int root=SmwSpcPlayer_GuitarRootMidi(g_spc_player);assert(root>=35 && root<=46);}
    long delta=NativeDifference(pcm,534);difference+=delta;energy+=Energy(pcm,1068);
    if(!layered)assert(delta==0);
    assert(fwrite(pcm,sizeof(pcm),1,f)==1);
  }
  fclose(f);assert(energy>100000);
  if(layered)assert(difference>100000);
  printf("%s: native PCM difference=%ld, energy=%ld, layer=%d\n",name,difference,energy,SmwSpcPlayer_MusicLayerMode(g_spc_player));
  return difference;
}
int main(int argc,char **argv){
  assert(argc==2);const char *dir=argv[1];MkDir(dir);PowerChordTests(dir);ElectricLeadTests(dir);
  assert(SDL_Init(0)==0);g_audio_mutex=SDL_CreateMutex();LoadAssets();assert(SnesInit(NULL,0));
  g_snes_width=256;g_snes_height=224;g_spc_player=SmwSpcPlayer_Create();g_spc_player->initialize(g_spc_player);
  PpuBeginDrawing(g_snes->ppu,g_pixels,1024,0);PpuBeginDrawing(g_my_ppu,g_my_pixels,1024,0);
  ShotgunSetStartArmed(false);for(int n=0;n<500;++n)Frame(n%100==0?0x108:0);LoadYoshisIsland1();
  for(int k=0;k<12;++k)spr_current_status[k]=0;
  player_current_power_up=0;
  Phrase(dir,"01-original",180,false);
  player_current_power_up=3;
  unsigned before=SmwSpcPlayer_MusicLayerNotes(g_spc_player);
  unsigned lead_before=SmwSpcPlayer_LeadGuitarNotes(g_spc_player);
  Phrase(dir,"02-shotgun-guitar",360,true);
  assert(SmwSpcPlayer_LeadGuitarNotes(g_spc_player)>lead_before+5);
  printf("Electric lead attacks=%u\n",SmwSpcPlayer_LeadGuitarNotes(g_spc_player)-lead_before);
  assert(SmwSpcPlayer_MusicLayerMode(g_spc_player)==1);
  assert(SmwSpcPlayer_MusicLayerNotes(g_spc_player)>before+5);
  printf("Metal source channel=%d, last root MIDI=%d, chord attacks=%u\n",SmwSpcPlayer_GuitarSource(g_spc_player),SmwSpcPlayer_GuitarRootMidi(g_spc_player),SmwSpcPlayer_GuitarPicks(g_spc_player));
  GivePlayerStarPower();for(int n=0;n<9;++n)Frame(0);
  assert(g_spc_player->port_to_snes[2]==13);
  Phrase(dir,"04-native-star",240,false);
  io_sound_ch3=1;Frame(0);Frame(0);
  int16 pcm[736*2];RtlRenderAudio(pcm,736,2);
  assert(!NativeDifference(pcm,736));assert(Energy(pcm,1472)>1000);
  timer_star_power=31;for(int n=0;n<9;++n)Frame(0);timer_star_power=0;Frame(0);
  assert(g_spc_player->port_to_snes[2]==(misc_music_register_backup&0x3f));
  Phrase(dir,"05-weapon-resumes",180,true);
  flag_pause=1;before=SmwSpcPlayer_MusicLayerNotes(g_spc_player);
  for(int n=0;n<10;++n){RtlRenderAudio(pcm,736,2);assert(!NativeDifference(pcm,736));}
  assert(SmwSpcPlayer_MusicLayerMode(g_spc_player)==-1);
  assert(SmwSpcPlayer_MusicLayerNotes(g_spc_player)==before);flag_pause=0;
  player_current_power_up=0;
  Phrase(dir,"06-damage-restores-original",120,false);
  player_current_power_up=3;player_current_state=9;RtlRenderAudio(pcm,736,2);
  assert(!NativeDifference(pcm,736));assert(!SmwSpcPlayer_MusicLayerMode(g_spc_player));
  puts("PASS: native note-synchronized weapon layers; native star and SFX bit-exact; pause, damage, death, expiry and device-rate resampling honored");
  return 0;
}
