# Super Mario World: restored full theme

Apply this source overlay to snesrev/smw revision eae20c65c58930c8b62c76188d259579ad4130f1.
It contains the public shotgun and Super Saiyan changes, the complete preferred
recorded-instrument metal arrangement, tests and the gameplay recorder.
No ROM, extracted Nintendo asset bundle, app or compiled binary is included.
See SHOTGUN.md for game asset extraction and build steps; install SDL2 and run
make -j8. Run make test for the integration and audio checks. Build and run
tests/showcase with an absolute capture folder to reproduce the full clip.

The shotgun comes from the flying question block. It recoils, ejects a shell
and defeats the level's native Rexes after the blast travels. Pellet graphics
are hidden; the muzzle flash, shell and blood stay visible. Stars grant the
Mario-proportioned Super Saiyan costume, short ki shots and a full-charge wave.
The full recording has six Rex hits, three short ki hits and an eight-Chuck
finisher in the separate practice course. The original star theme remains.

Equipping the shotgun changes the existing song's arrangement on its native
clock. The main melody on SPC channel 3 stays in front, with channels 0 and 1
supporting it, multi-sample guitars, the accepted rhythm balance, double-kick
drum tails and heavier bass. The arrangement exactly recovers the accepted mix.
Its only sound change is a post-mix gain of 0.23850637954651058;
the identical reference passage measures -30.37 LUFS
natively and -30.37 LUFS in this arrangement.
Native SFX and custom weapon effects bypass that gain. Star and unarmed audio
stay native. The tests require the main-melody lane, all three melodic parts,
separate note releases, alternating recordings and overlapping kick tails.

Code license: LICENSE.txt. Guitar/drum sample licenses and credits are in
MUSIC_CREDITS.txt and SAMPLE_LICENSES/. FreePats FSBS distorted guitar and
Virtuosity Drums are CC0; Ax_Grinder's chord recordings are CC BY 3.0.
Samples were excerpted, normalized, resampled and transposed for playback.
The original game's graphics, music and level data retain their owners' rights.
