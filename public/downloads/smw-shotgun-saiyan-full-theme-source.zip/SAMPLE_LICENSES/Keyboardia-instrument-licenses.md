# Instrument Sample Licenses

<!-- GENERATED FILE — do not edit by hand. -->
<!-- Source of truth: each instrument's manifest.json `credits` field. -->
<!-- Regenerate with: npm run generate:license -->

All samples used in Keyboardia are free to use, with licenses ranging
from Public Domain to CC0 to permissive free-use terms.

| Instrument | Source | License |
|---|---|---|
| 808 Clap (`808-clap`) | [TR-808 by Michael Fischer (1994), CC0 repackage (cp8/CP.WAV)](https://github.com/tidalcycles/sounds-tr808-fischer) | CC0 1.0 Universal (Public Domain) |
| 808 Hi-Hat (Closed) (`808-hihat-closed`) | [TR-808 by Michael Fischer (1994), CC0 repackage (ch8/CH.WAV)](https://github.com/tidalcycles/sounds-tr808-fischer) | CC0 1.0 Universal (Public Domain) |
| 808 Hi-Hat (Open) (`808-hihat-open`) | [TR-808 by Michael Fischer (1994), CC0 repackage (oh8/OH50.WAV)](https://github.com/tidalcycles/sounds-tr808-fischer) | CC0 1.0 Universal (Public Domain) |
| 808 Kick (`808-kick`) | [TR-808 by Michael Fischer (1994), CC0 repackage (bd8/BD5050.WAV)](https://github.com/tidalcycles/sounds-tr808-fischer) | CC0 1.0 Universal (Public Domain) |
| 808 Snare (`808-snare`) | [TR-808 by Michael Fischer (1994), CC0 repackage (sd8/SD5050.WAV)](https://github.com/tidalcycles/sounds-tr808-fischer) | CC0 1.0 Universal (Public Domain) |
| Crash Cymbal (`acoustic-crash`) | [Virtuosity Drums by Versilian Studios & Karoryfer Samples (mid mic)](https://github.com/sfzinstruments/virtuosity_drums) | CC0 1.0 Universal (Public Domain) |
| Acoustic Guitar (`acoustic-guitar`) | [Discord GM Bank - Martin HD28 Steel String (Jeff Learman)](https://github.com/sfzinstruments/Discord-SFZ-GM-Bank) | CC0 1.0 Universal (Public Domain) |
| Acoustic Hi-Hat (Closed) (`acoustic-hihat-closed`) | [Virtuosity Drums by Versilian Studios & Karoryfer Samples (mid mic)](https://github.com/sfzinstruments/virtuosity_drums) | CC0 1.0 Universal (Public Domain) |
| Acoustic Hi-Hat (Open) (`acoustic-hihat-open`) | [Virtuosity Drums by Versilian Studios & Karoryfer Samples (mid mic)](https://github.com/sfzinstruments/virtuosity_drums) | CC0 1.0 Universal (Public Domain) |
| Acoustic Kick (`acoustic-kick`) | [Virtuosity Drums by Versilian Studios & Karoryfer Samples (mid mic)](https://github.com/sfzinstruments/virtuosity_drums) | CC0 1.0 Universal (Public Domain) |
| Ride Cymbal (`acoustic-ride`) | [Virtuosity Drums by Versilian Studios & Karoryfer Samples (mid mic)](https://github.com/sfzinstruments/virtuosity_drums) | CC0 1.0 Universal (Public Domain) |
| Acoustic Snare (`acoustic-snare`) | [Virtuosity Drums by Versilian Studios & Karoryfer Samples (mid mic)](https://github.com/sfzinstruments/virtuosity_drums) | CC0 1.0 Universal (Public Domain) |
| Alto Sax (`alto-sax`) | [Karoryfer Weresax (Alto Saxophone)](https://github.com/sfzinstruments/karoryfer.weresax) | CC0 1.0 Universal (Public Domain) |
| Brush Snare (`brushes-snare`) | [Swirly Drums by Karoryfer Samples](https://github.com/sfzinstruments/karoryfer.swirly-drums) | CC0 1.0 |
| Clean Electric Guitar (`clean-guitar`) | [Karoryfer - Black and Green Guitars (Green Gretsch Anniversary)](https://github.com/sfzinstruments/karoryfer.black-and-green-guitars) | CC0 1.0 Universal (Public Domain) |
| Finger Bass (`finger-bass`) | [Karoryfer Meatbass](https://github.com/sfzinstruments/karoryfer.meatbass) | CC0 1.0 Universal (Public Domain) |
| French Horn (`french-horn`) | [VSCO 2 Community Edition (F Horn Sustain)](https://github.com/sgossner/VSCO-2-CE) | CC0 1.0 Universal (Public Domain) |
| Hammond Organ (`hammond-organ`) | [FreePats Project - Drawbar Organ Emulation (setBfree)](https://freepats.zenvoid.org/Organ/electric-organ.html) | CC0 1.0 Universal (Public Domain) |
| Kalimba (`kalimba`) | [VCSL (Kalimba, Kenya) — keys retuned to equal temperament (<=45 cents)](https://github.com/sgossner/VCSL) | CC0 1.0 Universal (Public Domain) |
| Marimba (`marimba`) | [Versilian Community Sample Library (VCSL)](https://github.com/sgossner/VCSL) | CC0 1.0 Universal (Public Domain) |
| Grand Piano (`piano`) | [University of Iowa Electronic Music Studios (Steinway grand, MIS)](https://theremin.music.uiowa.edu/MISpiano.html) | Free for any projects, without restrictions |
| Slap Bass (`slap-bass`) | [Karoryfer Growlybass](https://github.com/sfzinstruments/karoryfer.growlybass) | CC0 1.0 |
| Steel Drums (`steel-drums`) | [jSteelDrum v2 by Jack Learman (hand-made Trinidad steel pan)](https://github.com/sfzinstruments/jlearman.SteelDrum) | The Unlicense (Public Domain) |
| String Section (`string-section`) | [VSCO 2 Community Edition (Cello & Viola Sections)](https://github.com/sgossner/VSCO-2-CE) | CC0 1.0 Universal (Public Domain) |
| Vibraphone (`vibraphone`) | [Versilian Community Sample Library (VCSL)](https://github.com/sgossner/VCSL) | CC0 1.0 Universal (Public Domain) |
| Vinyl Crackle (`vinyl-crackle`) | [Procedurally Generated](https://keyboardia.com) | CC0 Public Domain |

## Sources

### FreePats Project - Drawbar Organ Emulation (setBfree)

- **URL:** https://freepats.zenvoid.org/Organ/electric-organ.html
- **License:** CC0 1.0 Universal (Public Domain)
- **Used by:** `hammond-organ`

### Discord GM Bank - Martin HD28 Steel String (Jeff Learman)

- **URL:** https://github.com/sfzinstruments/Discord-SFZ-GM-Bank
- **License:** CC0 1.0 Universal (Public Domain)
- **Used by:** `acoustic-guitar`

### jSteelDrum v2 by Jack Learman (hand-made Trinidad steel pan)

- **URL:** https://github.com/sfzinstruments/jlearman.SteelDrum
- **License:** The Unlicense (Public Domain) — https://github.com/sfzinstruments/jlearman.SteelDrum/blob/e429428dd65dc645e4c9b1f134da4d2e40c400c6/LICENSE
- **Keyboardia adaptation:** All usable SFZ mappings retained across 24 chromatic roots and five velocity zones; deterministic round-robin conversion; AAC-LC delivery and uniform group leveling. Delivery curated by objective defect, onset, headroom, DC, and within-layer level consistency metrics; at most two variants per tonal layer, four per snare velocity zone.
- **Used by:** `steel-drums`

### Karoryfer - Black and Green Guitars (Green Gretsch Anniversary)

- **URL:** https://github.com/sfzinstruments/karoryfer.black-and-green-guitars
- **License:** CC0 1.0 Universal (Public Domain)
- **Used by:** `clean-guitar`

### Karoryfer Growlybass

- **URL:** https://github.com/sfzinstruments/karoryfer.growlybass
- **License:** CC0 1.0
- **Used by:** `slap-bass`

### Karoryfer Meatbass

- **URL:** https://github.com/sfzinstruments/karoryfer.meatbass
- **License:** CC0 1.0 Universal (Public Domain) — https://github.com/sfzinstruments/karoryfer.meatbass/blob/ac9e859564bda286ab5ec672d00ff1aa2fef2895/LICENSE
- **Keyboardia adaptation:** Complete tonal pizzicato map: fourteen roots, four velocity layers, four deterministic round robins; AAC-LC delivery, uniform group leveling, and manifest trim calibrated to the canonical C4/MIDI-90 loudness contract. Delivery curated by objective defect, onset, headroom, DC, and within-layer level consistency metrics; at most two variants per tonal layer, four per snare velocity zone.
- **Used by:** `finger-bass`

### Swirly Drums by Karoryfer Samples

- **URL:** https://github.com/sfzinstruments/karoryfer.swirly-drums
- **License:** CC0 1.0
- **Used by:** `brushes-snare`

### Karoryfer Weresax (Alto Saxophone)

- **URL:** https://github.com/sfzinstruments/karoryfer.weresax
- **License:** CC0 1.0 Universal (Public Domain)
- **Used by:** `alto-sax`

### Virtuosity Drums by Versilian Studios & Karoryfer Samples (mid mic)

- **URL:** https://github.com/sfzinstruments/virtuosity_drums
- **License:** CC0 1.0 Universal (Public Domain) — https://github.com/sfzinstruments/virtuosity_drums/blob/9f04cf9a734527edfbb0a4eee1f674e45bbf71bc/LICENSE
- **Keyboardia adaptation:** Complete same-mic velocity/variation mapping; deterministic round-robin selection; AAC-LC delivery and uniform group leveling. Delivery curated by objective defect, onset, headroom, DC, and within-layer level consistency metrics; at most two variants per tonal layer, four per snare velocity zone.
- **Used by:** `acoustic-crash`, `acoustic-hihat-closed`, `acoustic-hihat-open`, `acoustic-kick`, `acoustic-ride`, `acoustic-snare`

### VCSL (Kalimba, Kenya) — keys retuned to equal temperament (<=45 cents)

- **URL:** https://github.com/sgossner/VCSL
- **License:** CC0 1.0 Universal (Public Domain)
- **Used by:** `kalimba`, `marimba`, `vibraphone`

### VSCO 2 Community Edition (F Horn Sustain)

- **URL:** https://github.com/sgossner/VSCO-2-CE
- **License:** CC0 1.0 Universal (Public Domain)
- **Used by:** `french-horn`, `string-section`

### TR-808 by Michael Fischer (1994), CC0 repackage (cp8/CP.WAV)

- **URL:** https://github.com/tidalcycles/sounds-tr808-fischer
- **License:** CC0 1.0 Universal (Public Domain)
- **Used by:** `808-clap`, `808-hihat-closed`, `808-hihat-open`, `808-kick`, `808-snare`

### Procedurally Generated

- **URL:** https://keyboardia.com
- **License:** CC0 Public Domain
- **Used by:** `vinyl-crackle`

### University of Iowa Electronic Music Studios (Steinway grand, MIS)

- **URL:** https://theremin.music.uiowa.edu/MISpiano.html
- **License:** Free for any projects, without restrictions
- **Used by:** `piano`

---

Use and redistribute each sample only under the license listed above.
CC BY entries require the stated attribution; Public Domain, CC0, and
Unlicense entries do not require attribution, though Keyboardia preserves it
when known.
