/* Recorded low power chords, driven by the native song's bass part. */
#include "metal_guitar.h"
#include "power_chord_samples.h"
#include "metal_performance_samples.h"
#include <math.h>
#include <string.h>
#define TAKE(pcm) {pcm, sizeof(pcm) / sizeof(pcm[0])}
#define GUITAR(root) {root, {TAKE(kGuitar##root##Take1), TAKE(kGuitar##root##Take2)}}
static const struct {
  int root;
  struct { const int16 *pcm; int length; } take[2];
} kRhythmBank[] = {GUITAR(36), GUITAR(40), GUITAR(45)};
#undef GUITAR
#undef TAKE

void MetalGuitar_BeginTrack(MetalGuitar *s){
  memset(s->sources,0,sizeof(s->sources));memset(s->voices,0,sizeof(s->voices));
  s->source_channel=-1;s->lowest_pitch=128;s->root_midi=36;s->next_voice=0;s->last_pick=~0u;
}
void MetalGuitar_Reset(MetalGuitar *s){memset(s,0,sizeof(*s));MetalGuitar_BeginTrack(s);}
static void Pick(MetalGuitar *s,MetalSource *note,bool accent){
  int pitch_class=((int)floor(note->midi+0.5))%12;
  /* Drop-B through Bb2: the accompaniment stays on the low strings. */
  s->root_midi=pitch_class==11?35:36+pitch_class;
  unsigned index;
  if(s->last_pick==s->clock)index=(s->next_voice-1)&1;
  else{index=s->next_voice++&1;for(int i=0;i<2;++i)s->voices[i].gate=false;++s->notes;}
  s->last_pick=s->clock;
  MetalVoice *v=&s->voices[index];memset(v,0,sizeof(*v));
  v->muted=!accent && note->seconds<0.20;v->gate=v->active=true;v->release=1;
  v->step=pow(2,(s->root_midi-kPowerChordRootMidi)/12.0);
  v->bank = s->root_midi < 38 ? 0 : s->root_midi < 43 ? 1 : 2;
  v->take = (s->next_voice >> 1) & 1;
  v->gain=0.9*pow(fmin(1,fmax(0,note->velocity)),0.3);
}
void MetalGuitar_SetEnabled(MetalGuitar *s,bool enabled){
  if(s->enabled==enabled)return;s->enabled=enabled;
  memset(s->voices,0,sizeof(s->voices));
  if(enabled && s->source_channel>=0 && s->sources[s->source_channel].valid)
    Pick(s,&s->sources[s->source_channel],true);
}
void MetalGuitar_NoteOn(MetalGuitar *s,int channel,double midi,double velocity,double seconds){
  if(channel<0 || channel>=8)return;
  MetalSource *note=&s->sources[channel];*note=(MetalSource){midi,velocity,seconds,true};
  /* Keep the lowest-register part as the harmonic source. Melody changes do
     not send the rhythm guitar jumping through high single-note figures. */
  if(s->source_channel<0 || midi<s->lowest_pitch-0.5){s->source_channel=channel;s->lowest_pitch=midi;}
  else if(channel==s->source_channel)s->lowest_pitch=fmin(s->lowest_pitch,midi);
  if(s->enabled && channel==s->source_channel)Pick(s,note,false);
}
void MetalGuitar_Chug(MetalGuitar *s) {
  if (!s->enabled || s->source_channel < 0 || s->last_pick == s->clock)
    return;
  MetalSource note = s->sources[s->source_channel];
  if (!note.valid)
    return;
  note.seconds = 0.10;
  Pick(s, &note, false);
}
void MetalGuitar_KeyOff(MetalGuitar *s, unsigned mask) {
  for (int channel = 0; channel < 8; ++channel)
    if (mask & (1u << channel))
      s->sources[channel].valid = false;
  if (s->source_channel >= 0 && (mask & (1u << s->source_channel)))
    for (int i = 0; i < 2; ++i)
      s->voices[i].gate = false;
}
static double Read(const int16 *pcm,int count,double pos){
  int i=(int)pos;if(i<0 || i>=count-1)return 0;
  double f=pos-i;return (pcm[i]*(1-f)+pcm[i+1]*f)/32768.0;
}
void MetalGuitar_Sample(MetalGuitar *s,double out[2]){
  out[0]=out[1]=0;++s->clock;if(!s->enabled)return;
  for(int i=0;i<2;++i){MetalVoice *v=&s->voices[i];if(!v->active)continue;
    const int16 *pcm=v->muted?kPowerChordMuted:kPowerChordOpen;
    int n=v->muted?sizeof(kPowerChordMuted)/sizeof(int16):sizeof(kPowerChordOpen)/sizeof(int16);
    if(v->pos>=n-1 || v->release<0.0001){v->active=false;continue;}
    if(!v->gate)v->release*=0.996;
    double env=fmin(1,v->age/0.0015)*v->gain*v->release;
    int anchor = kRhythmBank[v->bank].root;
    const int16 *right_root = kRhythmBank[v->bank].take[v->take].pcm;
    int root_size = kRhythmBank[v->bank].take[v->take].length;
    const int16 *right_fifth = kRhythmBank[v->bank].take[v->take ^ 1].pcm;
    int fifth_size = kRhythmBank[v->bank].take[v->take ^ 1].length;
    /* Keep the two performances independent. The right take voices a root
       and fifth with separate attacks and a short damping envelope on chugs. */
    double ratio = anchor == 36 ? 1.122462 : anchor == 40 ? 0.890899 : 0.667420;
    double right_at = (v->pos - 160) * ratio;
    double right = Read(right_root, root_size, right_at)
        + 0.62 * Read(right_fifth, fifth_size, (right_at - 32) * 1.498307);
    double damping = v->muted ? fmax(0, 1.0 - 10 * v->age) : 1.0;
    double left = Read(pcm, n, v->pos);
    out[0] += (left + 0.20 * right * damping) * env * 7600;
    out[1] += (0.18 * left + tanh(1.6 * right) * damping) * env * 7900;
    v->pos+=v->step;v->age+=1.0/kPowerChordSampleRate;
  }
}
