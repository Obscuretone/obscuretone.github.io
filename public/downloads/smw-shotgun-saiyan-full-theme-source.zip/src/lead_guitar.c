/* Single-note distorted electric guitar for the native melody and harmony.
   The low power-chord guitar has its own bass source and separate voices. */
#include "lead_guitar.h"
#include "metal_performance_samples.h"
#include <math.h>
#include <string.h>

#define RECORDING(pcm) {pcm, sizeof(pcm) / sizeof(pcm[0])}
#define GUITAR(root) {root, {RECORDING(kGuitar##root##Take1), RECORDING(kGuitar##root##Take2)}}
typedef struct Recording {
  const int16 *pcm;
  int length;
} Recording;
static const struct {
  int root;
  Recording take[2];
} kLeadBank[] = {
  GUITAR(48), GUITAR(55), GUITAR(59), GUITAR(64),
  GUITAR(67), GUITAR(72), GUITAR(77),
};
#undef GUITAR
#undef RECORDING

/* The Overworld tune is on SPC channel 3. Channels 0 and 1 are
   quicker supporting figures. Keep their key-offs independent. */
static const unsigned kSpcChannel[kLeadGuitarLaneCount] = {0, 1, 3};
static const double kLaneGain[kLeadGuitarLaneCount] = {0.58, 0.31, 1.58};
static const double kLanePan[kLeadGuitarLaneCount][2] = {
  {0.96, 0.57}, {0.58, 0.94}, {0.96, 0.96},
};

void LeadGuitar_BeginTrack(LeadGuitar *s) {
  memset(s->source, 0, sizeof(s->source));
  memset(s->voice, 0, sizeof(s->voice));
  memset(s->next, 0, sizeof(s->next));
}

void LeadGuitar_Reset(LeadGuitar *s) {
  memset(s, 0, sizeof(*s));
}

static void Pick(LeadGuitar *s, int channel) {
  LeadGuitarNote *note = &s->source[channel];
  for (int i = channel * 2; i < channel * 2 + 2; ++i)
    s->voice[i].gate = false;
  LeadGuitarVoice *v = &s->voice[channel * 2 + (s->next[channel]++ & 1)];
  memset(v, 0, sizeof(*v));
  double midi = note->midi;
  while (midi < 48) midi += 12;
  while (midi > 84) midi -= 12;
  v->channel = channel;
  unsigned bank = 0;
  for (unsigned i = 1; i < sizeof(kLeadBank) / sizeof(kLeadBank[0]); ++i)
    if (fabs(midi - kLeadBank[i].root) < fabs(midi - kLeadBank[bank].root))
      bank = i;
  v->bank = bank;
  v->take = (s->next[channel] - 1) & 1;
  v->step = pow(2, (midi - kLeadBank[bank].root) / 12.0);
  v->gain = 0.94 * pow(fmin(1, fmax(0, note->velocity)), 0.4);
  v->gain *= kLaneGain[channel];
  v->release = 1;
  v->gate = v->active = true;
  s->last_midi = midi;
  ++s->notes;
  ++s->notes_by_lane[channel];
}

void LeadGuitar_SetEnabled(LeadGuitar *s, bool enabled) {
  if (s->enabled == enabled) return;
  s->enabled = enabled;
  memset(s->voice, 0, sizeof(s->voice));
  if (enabled)
    for (int channel = 0; channel < kLeadGuitarLaneCount; ++channel)
      if (s->source[channel].held) Pick(s, channel);
}

void LeadGuitar_NoteOn(LeadGuitar *s, int channel, double midi, double velocity) {
  for (int lane = 0; lane < kLeadGuitarLaneCount; ++lane) {
    if (channel != (int)kSpcChannel[lane])
      continue;
    s->source[lane] = (LeadGuitarNote){midi, velocity, true};
    if (s->enabled)
      Pick(s, lane);
    return;
  }
}

void LeadGuitar_KeyOff(LeadGuitar *s, unsigned mask) {
  for (int channel = 0; channel < kLeadGuitarLaneCount; ++channel) {
    if (!(mask & (1u << kSpcChannel[channel]))) continue;
    s->source[channel].held = false;
    for (int i = channel * 2; i < channel * 2 + 2; ++i)
      s->voice[i].gate = false;
  }
}

void LeadGuitar_Sample(LeadGuitar *s, double out[2]) {
  out[0] = out[1] = 0;
  if (!s->enabled) return;
  for (int i = 0; i < kLeadGuitarLaneCount * 2; ++i) {
    LeadGuitarVoice *v = &s->voice[i];
    if (!v->active) continue;
    Recording sample = kLeadBank[v->bank].take[v->take];
    int at = (int)v->position;
    if (at >= sample.length - 1 || v->release < 0.0001) {
      v->active = false;
      continue;
    }
    if (!v->gate) v->release *= 0.995;
    double fraction = v->position - at;
    double value = (sample.pcm[at] * (1 - fraction) +
                    sample.pcm[at + 1] * fraction) / 32768.0;
    value *= fmin(1, v->age / 0.0015) * v->gain * v->release * 8000;
    out[0] += value * kLanePan[v->channel][0];
    out[1] += value * kLanePan[v->channel][1];
    double vibrato = v->age > 0.14 ? 0.006 * sin(35.19 * v->age) : 0;
    v->position += v->step * (1 + vibrato);
    v->age += 1.0 / 32000;
  }
}
