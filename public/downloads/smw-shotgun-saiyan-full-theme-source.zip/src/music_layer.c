/* Instrument arrangements driven by the native score and its sequencer clock. */
#include "music_layer.h"
#include "metal_performance_samples.h"
#include <math.h>
#include <string.h>
static const double tau=6.283185307179586;
/* One post-arrangement trim: preserve the accepted melody, rhythm, bass and
   drum balance. Native SFX are mixed separately and never receive this gain. */
static const double kMetalMusicGain=0.23850637954651058;
void MusicLayer_Reset(MusicLayer *s){memset(s,0,sizeof(*s));s->random=0x48ab317;MetalGuitar_Reset(&s->guitar);LeadGuitar_Reset(&s->lead);}
void MusicLayer_BeginTrack(MusicLayer *s) {
  MetalGuitar_BeginTrack(&s->guitar);
  LeadGuitar_BeginTrack(&s->lead);
  s->rhythm_tick = 0;
  s->band = (MetalBand){0};
}
static void TriggerKick(MetalBand *band, double gain) {
  band->kick_tail = band->kick;
  band->kick_tail_gain = band->kick_gain;
  band->kick = 0;
  band->kick_take ^= 1;
  band->kick_gain = gain;
}

void MusicLayer_Tick(MusicLayer *s) {
  if (s->paused)
    return;
  // Six ticks per sixteenth note. Keep counting while unarmed.
  static const unsigned chug_steps[] = {
    (1u << 3) | (1u << 4) | (1u << 6) | (1u << 11) | (1u << 14),
    (1u << 2) | (1u << 3) | (1u << 6) | (1u << 10) | (1u << 14),
    (1u << 3) | (1u << 4) | (1u << 6) | (1u << 11) | (1u << 14),
    (1u << 2) | (1u << 6) | (1u << 11) | (1u << 13) | (1u << 15),
  };
  unsigned tick = s->rhythm_tick++;
  if (s->mode != 1)
    return;

  unsigned subdivision = tick / 6;
  unsigned bar = (subdivision / 16) % 4;
  unsigned step = subdivision % 16;
  unsigned phase = tick % 6;
  if (phase != 0) {
    // Double-pedal pickups between selected sixteenth-note accents.
    bool pickup = (bar == 1 && (step == 2 || step == 14))
        || (bar == 3 && (step == 6 || step == 13 || step == 15));
    if (phase == 3 && pickup)
      TriggerKick(&s->band, 0.16);
    return;
  }

  bool chug = (chug_steps[bar] & (1u << step)) != 0;
  if (chug)
    MetalGuitar_Chug(&s->guitar);
  if (chug || step == 0 || step == 8 || step == 10)
    TriggerKick(&s->band, step % 4 == 0 ? 0.25 : 0.17);
  if (step == 4 || step == 12 || (bar == 3 && step == 14)) {
    s->band.snare = 0;
    s->band.snare_take ^= 1;
    s->band.snare_gain = step == 14 ? 0.11 : 0.25;
  }
  if (step % 4 == 0 || (bar == 3 && step == 14)) {
    s->band.cymbal = 0;
    s->band.cymbal_take ^= 1;
    s->band.cymbal_gain = step == 0 && bar % 2 == 0 ? 0.17 : 0.055;
  }
}
void MusicLayer_SetMode(MusicLayer *s,int mode){
  s->paused=mode<0;
  if(mode<0)return;
  if(mode!=s->mode) {
    s->gain=0;
    s->band = (MetalBand){0};
    s->band_pick = ~0u;
  }
  s->mode=mode;MetalGuitar_SetEnabled(&s->guitar,mode==1);LeadGuitar_SetEnabled(&s->lead,mode==1);
  if(!mode){s->gain=0;s->filtered[0]=s->filtered[1]=0;}
}
static double Noise(MusicLayer *s){
  s->random^=s->random<<13;s->random^=s->random>>17;s->random^=s->random<<5;
  return ((int)(s->random&65535)-32768)/32768.0;
}
void MusicLayer_NoteOn(MusicLayer *s,int channel,double midi,double velocity,double seconds){
  if(s->paused)return;
  MetalGuitar_NoteOn(&s->guitar,channel,midi,velocity,seconds);
  LeadGuitar_NoteOn(&s->lead,channel,midi,velocity);
  if(channel<0 || channel>1)return;
  /* Keep a real guitar register; octave folding preserves the song's key. */
  while(midi<40)midi+=12;
  while(midi>83)midi-=12;
  MusicString *v=&s->voices[channel];
  double hz=440*pow(2,(midi-69)/12.0);
  v->delay=32000/hz-0.5;v->write=0;v->previous=0;
  v->age=0;v->release=1;v->velocity=velocity;v->gate=v->active=true;
  for(int i=0;i<1024;++i){
    double p=tau*i/(v->delay+0.5);
    v->line[i]=0.32*Noise(s)+0.45*sin(p)+0.18*sin(2*p)+0.08*sin(3*p);
  }
  ++s->notes;
}
void MusicLayer_KeyOff(MusicLayer *s,unsigned mask){
  MetalGuitar_KeyOff(&s->guitar,mask);
  LeadGuitar_KeyOff(&s->lead,mask);
  for(int i=0;i<2;++i)if(mask&(1u<<i))s->voices[i].gate=false;
}
static double ReadString(MusicString *v,double delay){
  double at=v->write-delay;while(at<0)at+=1024;
  unsigned i=(unsigned)at;double f=at-i;
  return v->line[i&1023]*(1-f)+v->line[(i+1)&1023]*f;
}
#define DRUM(pcm) {pcm, sizeof(pcm) / sizeof(pcm[0])}
typedef struct DrumTake {
  const int16 *pcm;
  unsigned length;
} DrumTake;
static const DrumTake kKick[] = {DRUM(kKick1), DRUM(kKick2)};
static const DrumTake kSnare[] = {DRUM(kSnare1), DRUM(kSnare2)};
static const DrumTake kCymbal[] = {DRUM(kCrash1), DRUM(kCrash2)};
#undef DRUM

static double DrumSample(DrumTake take, unsigned *position, double gain) {
  if (*position >= take.length || !gain)
    return 0;
  return take.pcm[(*position)++] * gain;
}

static void MetalBand_Sample(MusicLayer *s, double out[2]) {
  MetalBand *band = &s->band;
  double kick = DrumSample(kKick[band->kick_take], &band->kick, band->kick_gain);
  kick += 0.58 * DrumSample(kKick[band->kick_take ^ 1], &band->kick_tail, band->kick_tail_gain);
  double snare = DrumSample(kSnare[band->snare_take], &band->snare, band->snare_gain);
  band->snare_low += 0.19 * (snare - band->snare_low);
  snare += 0.25 * (snare - band->snare_low);
  double cymbal = DrumSample(kCymbal[band->cymbal_take], &band->cymbal, band->cymbal_gain);

  int channel = s->guitar.source_channel;
  bool playing = channel >= 0 && s->guitar.sources[channel].valid;
  double level = playing ? 1.0 : 0.0;
  band->bass_level += 0.018 * (level - band->bass_level);
  band->bass_phase += band->bass_step;
  if (band->bass_phase >= tau)
    band->bass_phase -= tau;
  // A solid low fundamental plus a parallel driven layer of upper harmonics.
  double fundamental = sin(band->bass_phase);
  double drive = tanh(1.7 * sin(2 * band->bass_phase)
      + 0.62 * sin(3 * band->bass_phase) + 0.32 * sin(5 * band->bass_phase));
  double bass = band->bass_level * (2550 * fundamental + 1180 * drive);
  out[0] = kick + snare + bass + 0.35 * cymbal;
  out[1] = kick + snare + bass + cymbal;
}

void MusicLayer_Sample(MusicLayer *s,int offset){
  if(offset<0 || offset>=534)return;
  if(s->paused){s->samples[offset*2]=s->samples[offset*2+1]=0;return;}
  s->gain+=(1-s->gain)*0.0009;
  double mix[2]={0,0};
  for(int i=0;i<2;++i){
    MusicString *v=&s->voices[i];if(!v->active)continue;
    double y=ReadString(v,v->delay);
    v->line[v->write]=0.9988*(y+v->previous)*0.5;
    v->previous=y;v->write=(v->write+1)&1023;
    double attack=fmin(1,v->age/0.002);
    if(!v->gate)v->release*=0.9935;
    if(v->release<0.0001)v->active=false;
    double value=tanh(2.9*y)*2900;

    value*=attack*v->release*v->velocity*(i==0?1.0:0.48);
    mix[0]+=value*(i==0?0.82:0.60);mix[1]+=value*(i==0?0.68:0.84);
    v->age+=1.0/32000;
  }
  double chords[2];MetalGuitar_Sample(&s->guitar,chords);
  double lead[2];LeadGuitar_Sample(&s->lead,lead);
  if (s->mode == 1) {
    if (s->guitar.notes != s->band_pick) {
      s->band_pick = s->guitar.notes;
      s->band.bass_step = tau * 440 * pow(2, (s->guitar.root_midi - 81) / 12.0) / 32000;
    }
    double band[2];
    MetalBand_Sample(s, band);
    for (int ch = 0; ch < 2; ++ch) {
      double rhythm = 5800.0 * tanh(chords[ch] / 4850.0);
      mix[ch] = 20500 * tanh((rhythm + 1.16 * lead[ch] + 0.79 * band[ch]) / 20500);
    }
  }
  for(int ch=0;ch<2;++ch){
    s->filtered[ch]+=(mix[ch]-s->filtered[ch])*0.48;
    s->samples[offset*2+ch]=s->mode?s->filtered[ch]*s->gain*(s->mode==1?kMetalMusicGain:1.0):0;
  }
}
void MusicLayer_Mix(MusicLayer *s,int16 *pcm,int frames){
  if(frames<=0)return;
  /* Match the native DSP's exact 534-sample block resampling positions. */
  double at=0,step=534.0/frames;
  for(int i=0;i<frames;++i,at+=step)for(int ch=0;ch<2;++ch){
    int value=pcm[i*2+ch]+(int)s->samples[(int)at*2+ch];
    pcm[i*2+ch]=value>32767?32767:value<-32768?-32768:value;
  }
}
