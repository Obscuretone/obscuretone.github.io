#pragma once
#include "types.h"

typedef struct Dsp Dsp;
typedef struct SpcPlayer SpcPlayer;

typedef void SpcPlayer_Initialize_Func(SpcPlayer *p);
typedef void SpcPlayer_GenerateSamples_Func(SpcPlayer *p);
typedef void SpcPlayer_Upload_Func(SpcPlayer *p, const uint8_t *data);
typedef void SpcPlayer_CopyVariables_Func(SpcPlayer *p, bool copy_to_ram);


typedef struct SpcPlayer {
  Dsp *dsp;
  uint8 *ram;
  uint8 input_ports[4];
  uint8 port_to_snes[4];

  SpcPlayer_Initialize_Func *initialize;
  SpcPlayer_GenerateSamples_Func *gen_samples;
  SpcPlayer_Upload_Func *upload;
  SpcPlayer_CopyVariables_Func *copy_vars;
} SpcPlayer;


SpcPlayer *SmwSpcPlayer_Create(void);
SpcPlayer *SmasSpcPlayer_Create(void);


void SmwSpcPlayer_SetMusicMuted(SpcPlayer *player, bool muted);

void SmwSpcPlayer_SetMusicLayer(SpcPlayer *player,int mode);
void SmwSpcPlayer_MixMusicLayer(SpcPlayer *player,int16 *pcm,int frames);
unsigned SmwSpcPlayer_MusicLayerNotes(SpcPlayer *player);
int SmwSpcPlayer_MusicLayerMode(SpcPlayer *player);

int SmwSpcPlayer_GuitarRootMidi(SpcPlayer *player);
int SmwSpcPlayer_GuitarSource(SpcPlayer *player);
unsigned SmwSpcPlayer_GuitarPicks(SpcPlayer *player);

unsigned SmwSpcPlayer_LeadGuitarNotes(SpcPlayer *player);
unsigned SmwSpcPlayer_MainMelodyNotes(SpcPlayer *player);
