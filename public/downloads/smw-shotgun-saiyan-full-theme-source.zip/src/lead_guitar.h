#pragma once
#include "types.h"

enum { kLeadGuitarLaneCount = 3 };

typedef struct LeadGuitarNote {
  double midi, velocity;
  bool held;
} LeadGuitarNote;

typedef struct LeadGuitarVoice {
  double position, step, gain, release, age;
  int channel;
  unsigned bank, take;
  bool gate, active;
} LeadGuitarVoice;

typedef struct LeadGuitar {
  LeadGuitarNote source[kLeadGuitarLaneCount];
  LeadGuitarVoice voice[kLeadGuitarLaneCount * 2];
  unsigned next[kLeadGuitarLaneCount], notes;
  unsigned notes_by_lane[kLeadGuitarLaneCount];
  double last_midi;
  bool enabled;
} LeadGuitar;

void LeadGuitar_Reset(LeadGuitar *s);
void LeadGuitar_BeginTrack(LeadGuitar *s);
void LeadGuitar_SetEnabled(LeadGuitar *s, bool enabled);
void LeadGuitar_NoteOn(LeadGuitar *s, int channel, double midi, double velocity);
void LeadGuitar_KeyOff(LeadGuitar *s, unsigned mask);
void LeadGuitar_Sample(LeadGuitar *s, double out[2]);
