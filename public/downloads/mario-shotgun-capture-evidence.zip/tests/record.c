/* Record native gameplay, game audio, input and observable enemy removals. */
#define SMW_CAPTURE_MAIN
#include "headless.c"

static FILE *video_file, *audio_file, *events_file;
static int kills, shots, block_hits;

static void RecordFrame(unsigned input, int n) {
  uint8 status[12], ids[12], block_state[12];
  uint16 xs[12], ys[12];
  for (int k = 0; k < 12; ++k) {
    block_state[k] = spr_table00c2[k];
    status[k] = spr_current_status[k]; ids[k] = spr_spriteid[k];
    xs[k] = GetSprXPos(k); ys[k] = GetSprYPos(k);
  }
  int previous_pose_timer = timer_display_player_shoot_fireball_pose;
  RtlRunFrame(input | (1u << 30));
  assert(PPU_mosaicSize(g_ppu) == 1);
  SmwDrawPpuFrame();
  uint32 pixels[256 * 224];
  memcpy(pixels, g_my_pixels, sizeof(pixels));
  ShotgunDraw((uint8 *)pixels, 1024, 256, 224);
  assert(fwrite(pixels, 1, sizeof(pixels), video_file) == sizeof(pixels));
  /* SMW advances 534 samples at 32 kHz per frame. Keep the captured sound. */
  int16 audio[534 * 2];
  RtlRenderAudio(audio, 534, 2);
  ShotgunMixAudio(audio, 534, 2, 32000);
  assert(fwrite(audio, 1, sizeof(audio), audio_file) == sizeof(audio));
  bool fired = timer_display_player_shoot_fireball_pose == 12 && previous_pose_timer != 12;
  if (fired) ++shots;
  fprintf(events_file, "{\"frame\":%d,\"input\":%u,\"x\":%u,\"y\":%u,\"state\":%u,\"power\":%u,\"dragon_coins\":%u,\"air\":%u,\"fired\":%s,\"removed\":[",
      n, input, player_xpos, player_ypos, player_current_state, player_current_power_up, counter_yoshi_coins_collected, player_in_air_flag, fired ? "true" : "false");
  int removed = 0;
  for (int k = 0; k < 12; ++k) {
    if (!fired || status[k] < 8 || status[k] > 10 || spr_current_status[k] != 0) continue;
    int sx = (int16)(xs[k] - mirror_current_layer1_xpos);
    int sy = (int16)(ys[k] - mirror_current_layer1_ypos);
    if (sx < -32 || sx > 256 || sy < 16 || sy > 224) continue;
    fprintf(events_file, "%s{\"slot\":%d,\"sprite_id\":%u,\"x\":%u,\"y\":%u}", removed ? "," : "", k, ids[k], xs[k], ys[k]);
    ++removed; ++kills;
  }
  fprintf(events_file, "],\"flying_blocks\":[");
  int blocks = 0;
  for (int k = 0; k < 12; ++k) {
    if (spr_current_status[k] != 8 || (spr_spriteid[k] != 0x83 && spr_spriteid[k] != 0x84)) continue;
    bool hit = status[k] == 8 && ids[k] == spr_spriteid[k] && !block_state[k] && spr_table00c2[k];
    if (hit) ++block_hits;
    fprintf(events_file, "%s{\"slot\":%d,\"id\":%u,\"x\":%u,\"y\":%u,\"state\":%u,\"hit\":%s}", blocks++ ? "," : "", k, spr_spriteid[k], GetSprXPos(k), GetSprYPos(k), spr_table00c2[k], hit ? "true" : "false");
  }
  fprintf(events_file, "],\"music_track\":%u}\n", g_spc_player->port_to_snes[2]);
}
int main(int argc, char **argv) {
  assert(argc == 2);
  output_dir = argv[1];
  MkDir(output_dir);
  assert(SDL_Init(0) == 0);
  g_new_ppu = getenv("SMW_CAPTURE_REFERENCE_RENDERER") == NULL;
  g_audio_mutex = SDL_CreateMutex();
  LoadAssets();
  assert(SnesInit(NULL, 0));
  g_snes_width = 256; g_snes_height = 224;
  g_spc_player = SmwSpcPlayer_Create();
  g_spc_player->initialize(g_spc_player);
  PpuBeginDrawing(g_snes->ppu, g_pixels, 1024, 0);
  PpuBeginDrawing(g_my_ppu, g_my_pixels, 1024, 0);
  ShotgunSetStartArmed(true);
  /* Boot the game normally, then request native level 0x105. No placed enemies. */
  for (int n = 0; n < 500; ++n) Frame(n % 100 == 0 ? 0x108 : 0);
  LoadYoshisIsland1();
  assert(misc_game_mode == 0x14 && player_current_power_up == 3);
  char path[4096];
  snprintf(path, sizeof(path), "%s/game.bgra", output_dir); video_file = fopen(path, "wb");
  snprintf(path, sizeof(path), "%s/game.s16le", output_dir); audio_file = fopen(path, "wb");
  snprintf(path, sizeof(path), "%s/events.jsonl", output_dir); events_file = fopen(path, "w");
  assert(video_file && audio_file && events_file);
  int last_trigger = -100, chain_complete = -1, coin_jump = -1, ledge_jump = -1, block_jump = -1;
  int visible_since[12], previous_id[12], previous_load[12];
  for (int k = 0; k < 12; ++k) visible_since[k] = previous_id[k] = previous_load[k] = -1;
  for (int n = 0; n < 1800; ++n) {
    unsigned input = n < 60 ? 0 : 128; /* Walk between enemies; press Y only to fire. */
    bool target_ahead = false;
    for (int k = 0; k < 12; ++k) {
      int sx = (int16)(GetSprXPos(k) - mirror_current_layer1_xpos);
      bool visible = spr_current_status[k] == 8 && sx >= 8 && sx < 240;
      if (!visible || previous_id[k] != spr_spriteid[k] || previous_load[k] != spr_load_status_table_index[k])
        visible_since[k] = -1;
      if (visible && visible_since[k] < 0) visible_since[k] = n;
      previous_id[k] = spr_spriteid[k];
      previous_load[k] = spr_load_status_table_index[k];
      if (!visible || (spr_spriteid[k] != 2 && spr_spriteid[k] != 0xab && spr_spriteid[k] != 0x9f)) continue;
      CollInfo ci = {0};
      StandardSpriteToSpriteCollisionChecks_GetSpriteClippingA(k, &ci);
      int dx = (int16)(PAIR16(ci.r10, ci.r4) - player_xpos);
      int dy = (int16)(PAIR16(ci.r11, ci.r5) - player_ypos);
      /* Let enemies establish themselves on screen, then shoot up close. */
      int far = dx - 8 + ci.r6;
      int spread = 10 + (far < 96 ? far : 96) / 5;
      if (n - visible_since[k] >= 36 && dx > 4 && dx < 80 &&
          dy < 21 + spread - 3 && dy + ci.r7 > 21 - spread + 3)
        target_ahead = true;
    }
    if (n >= 60 && target_ahead && n - last_trigger > 40) {
      input |= 2;
      last_trigger = n;
    }

    /* Jump only for the Dragon Coin, the flying question block and the ledge. */
    for (int k = 0; k < 12; ++k) {
      int dx = (int16)(GetSprXPos(k) - player_xpos);
      if (block_jump < 0 && counter_yoshi_coins_collected && !player_in_air_flag &&
          spr_current_status[k] == 8 && spr_spriteid[k] == 0x83 &&
          !spr_table00c2[k] && dx > 12 && dx < 30) block_jump = n;
    }
    if (block_jump >= 0 && n - block_jump < 12) input |= 1;
    if (coin_jump < 0 && player_xpos >= 232) coin_jump = n;
    if (coin_jump >= 0 && n - coin_jump < 28) input |= 1;
    if (ledge_jump < 0 && player_xpos >= 764) ledge_jump = n;
    if (ledge_jump >= 0 && n - ledge_jump < 30) input |= 1;
    if (chain_complete >= 0) input = 0;
    RecordFrame(input, n);
    if (player_current_state == 9) {
      fprintf(stderr, "Died at frame %d x=%u, kills=%d\n", n, player_xpos, kills);
      break;
    }
    if (kills >= 6 && chain_complete < 0) chain_complete = n;
    if (chain_complete >= 0 && n - chain_complete > 100) break;
  }
  fclose(video_file); fclose(audio_file); fclose(events_file);
  printf("Recorded %d observed removals over %d shots; block hits=%d; final x=%u state=%u\n", kills, shots, block_hits, player_xpos, player_current_state);
  return kills >= 6 && shots == 6 && counter_yoshi_coins_collected >= 1 &&
      block_hits == 1 && player_current_state != 9 && player_current_power_up == 3 ? 0 : 1;
}
