# Super Mario World: Shotgun and Super Saiyan

A native Mac mod of the actual reverse-engineered Super Mario World game.

## Play

Open **Super Mario World Shotgun.app**. The bundled Mac build is for Apple Silicon and includes SDL2; an emulator is unnecessary.

- **Enter:** start / confirm menu selections
- **Arrow keys:** move / aim left or right
- **Z:** jump
- **X:** spin jump
- **A or S:** shoot / run (SNES Y or X)
- **P:** pause
- **Alt + Enter:** full screen

Mario starts unarmed. The flower variant of the flying question block releases a shotgun, even for small Mario. Touch the pickup to acquire it; firing is unavailable before collection, and the world pickup disappears when collected. Fire flowers elsewhere and in the reserve box also appear as shotguns. Mario keeps his regular red-and-blue outfit. Taking damage follows the normal game's power-up rules. The optional source-build flag `./smw --shotgun-start` still starts armed for testing.

The shotgun has unlimited ammunition and a 28-frame pump cycle. A visible spread of nine pellets advances 12 game pixels per frame through a widening cone, capped at 96 pixels ahead of Mario within the visible playfield. Damage is applied only as that front reaches the hostile. The blast penetrates scenery. It ignores normal fire immunity and includes enemy projectiles and cluster ghosts. Friendly characters, platforms, power-ups, keys and goal objects are preserved.

Effects include original pixel shotgun art, recoil, a muzzle flash, pellet trails, smoke, a tumbling red-and-brass shell, slower, longer-lived red blood particles, a steady camera, a synthesized blast, and pump sounds. The grip follows the white glove pixels in Mario's animated native body tile, including facing, ducking and Yoshi poses. The original native glove pixels remain visible over the stock. Shots preserve the holding pose instead of switching to the fireball throw or recoil skid pose, and the muzzle flash follows the held barrel as Mario moves backward. The larger red-and-brass hull ejects 12 frames after the shot, during the pump. The pickup is masked behind the actual block edge while it emerges. Attacks also work while swimming and climbing. Bosses enter their native defeat/exit sequences so the level can continue.

Saves and the app's editable `smw.ini` live in `~/Library/Application Support/SMW Shotgun/`. The source build uses its local `saves/` folder. Transient particles and reload effects clear on reset or snapshot load.

## Source and build

The editable implementation is in `src/shotgun.c`, with hooks in the existing player, sprite, rendering and sound code. It modifies the complete game; this is a native port mod rather than a standalone recreation of one level or an emulator ROM patch.

On this Mac, build tools and SDL2 are already installed. From this directory:

```sh
make -j8
./smw
make test
python3 tools/package_macos.py
```

Elsewhere, install a C compiler, Make and SDL2 development files first. The provided `smw_assets.dat` contains the reconstructed game resources. The native build does not need a ROM once this asset file exists. To extract resources from a separate US game image, use:

```sh
python3 assets/restool.py --rom /absolute/path/to/smw.sfc --no-include-rom
```

The upstream extractor checks the unheadered US image against SHA-1 `6b47bb75d16514b6a476aa0c73a683a2a4c18765`.

## Validation

`make test` runs the real game headlessly with its actual assets, collision tables, PPU and sound engine. It boots through the menus, loads a game level, fires through the Y-button input handler, checks kills and preservation of a shotgun pickup, and captures the animation. It also checks left/right targeting, fire immunity, targets outside the cone, off-screen targets, page crossings, projectiles, cluster sprites, reload/pause gates, player state gates, pixel-buffer bounds and synthesized sound. All seven Koopaling variants have checks for the selected native defeat states.

Screenshots are written to a temporary folder printed by the test; set `SMW_TEST_OUTPUT_DIR` to select an existing destination. The test scene positions enemies deliberately to make the results reproducible. A complete playthrough and every boss cutscene have not been tested.

The separate `tests/record` tool captures the native level's own enemies. Its direct level-load setup initializes the fade-out mosaic state before fading in, and asserts that mosaic pixel grouping is disabled throughout recorded gameplay. This prevents the hill shimmer seen in the first video. Set `SMW_CAPTURE_REFERENCE_RENDERER=1` to record with the slower reference renderer for comparison.

## Provenance and licenses

- Native C base: [snesrev/smw](https://github.com/snesrev/smw), commit `eae20c65c58930c8b62c76188d259579ad4130f1`. The upstream MIT license and dependency notices remain in `LICENSE.txt`.
- Assembly reconstruction: [IsoFrieze/SMWDisX](https://github.com/IsoFrieze/SMWDisX), built as its US version using [Asar 1.91](https://github.com/RPGHacker/asar/tree/v1.91). The reconstructed 524,288-byte image matched the SHA-1 above before resource extraction.
- SDL2 is bundled in the Mac app with its license notice.
- Shotgun art, particle effects and procedural sound are new code in this modification. Super Mario World characters, original graphics, music and level data remain Nintendo's.

## Super Saiyan star power

Star pickups are pulsing golden four-star ki orbs. Collection applies spiky gold
hair and an orange gi directly to Mario's native head/body tiles, preserving his
face and proportions. The original star invincibility duration remains.
Hold A (SNES Y) for 12–180 frames, then release a travelling ki wave. Short charges
make small pulses; a full three-second charge makes a 45-pixel beam. The charge
ball remains at hand height, grows forward clear of Mario, and releases a beam
with the same diameter. Enemy hits follow its visible moving round front.

Run `./smw --ki-showcase` for the separate five-screen practice course. Collect its
ki orb, try three short shots, then aim a full charge between the two Chuck racks.
Select resets the course. Ordinary campaign levels retain their original layout.
`make tests/showcase` builds the recorder; run it with an absolute output folder.
It records the original six-Rex shotgun run, a native level transition, three
short ki hits and an eight-Chuck charged finish with game audio.

Star music uses an eight-voice chiptune arrangement of Cha-La Head-Cha-La:
a softer harmonic pulse lead, triangle bass, three lower chord voices, and
independent kick, snare and hi-hat voices with light stereo echo. Only native music-owned SPC voices are muted;
jump, pickup and attack sound effects remain. Pause freezes the tune, another ki
orb restarts it, and the level music returns when star power ends.
MIDI reference: https://bitmidi.com/ricardo-silva-chala-head-chala-mid
Sequencer credit in that reference: (C)1994 Roland Corporation.
