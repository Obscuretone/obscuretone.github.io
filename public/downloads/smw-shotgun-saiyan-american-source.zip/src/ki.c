/* Super Saiyan star power: native Mario costume and travelling ki shots. */
#include "ki.h"
#include "shotgun.h"
#include "smw_rtl.h"
#include "variables.h"
#include "funcs.h"
#include "common_rtl.h"
#include "assets/smw_assets.h"
#include <string.h>
static int charge,serial,hits;
static struct {int x,y,dir,power,life,travelled;} wave;
static struct {int x,y;} pickups[12],impacts[12];
static int pickup_count,impact_life,impact_count;
int KiChargeFrames(void){return charge;}
int KiWaveSerial(void){return serial;}
int KiWaveHits(void){return hits;}
int KiWavePower(void){return wave.power;}
void KiReset(void){charge=serial=hits=pickup_count=impact_life=impact_count=0;memset(&wave,0,sizeof(wave));}
void KiBeginFrame(void){pickup_count=0;}
void KiRegisterPickup(int x,int y){if(pickup_count<12){pickups[pickup_count].x=x;pickups[pickup_count++].y=y;}}
static int Radius(int power){return 2+power/9;}
static int HandY(void){return player_ypos+(player_ducking_flag?23:17)+(player_riding_yoshi_flag?(yoshi_ducking_flag?12:4):0);}
void KiTick(void){
  if(impact_life && !--impact_life)impact_count=0;
  if(timer_star_power && !player_current_state){
    if(io_controller_hold1&0x40){if(charge<180)++charge;timer_display_player_shoot_fireball_pose=2;}
    else if(charge){
      if(charge>=12){wave.dir=player_facing_direction?1:-1;wave.power=charge;
        wave.x=player_xpos+8+wave.dir*(8+Radius(charge));wave.y=HandY();wave.life=32;wave.travelled=0;
        ++serial;io_sound_ch3=9;timer_display_player_shoot_fireball_pose=18;}
      charge=0;
    }
  }else charge=0;
  if(!wave.life)return;
  --wave.life;wave.x+=wave.dir*12;wave.travelled+=12;
  int radius=Radius(wave.power);
  for(int k=0;k<12;++k){
    if(spr_current_status[k]<8||spr_current_status[k]>10||!ShotgunIsHostile(spr_spriteid[k])||ShotgunBossDying(k))continue;
    CollInfo c={0};StandardSpriteToSpriteCollisionChecks_GetSpriteClippingA(k,&c);
    int x=PAIR16(c.r10,c.r4),y=PAIR16(c.r11,c.r5);
    int sx=(int16)(x-mirror_current_layer1_xpos),sy=(int16)(y-mirror_current_layer1_ypos);
    if(sx+c.r6<0||sx>=256||sy+c.r7<32||sy>=224)continue;
    int left=wave.dir>0?-12:0,right=wave.dir>0?0:12,dx=(int16)(x-wave.x),dy=(int16)(y-wave.y);
    dx=dx>right?dx-right:dx+c.r6<left?dx+c.r6-left:0;
    dy=dy>0?dy:dy+c.r7<0?dy+c.r7:0;
    if(dx*dx+dy*dy>radius*radius)continue;
    if(!impact_life)impact_count=0;
    if(impact_count<12){impacts[impact_count].x=x+c.r6/2;impacts[impact_count++].y=y+c.r7/2;}
    impact_life=18;ShotgunDefeat(k);++hits;
  }
}
typedef struct {uint8 *p;size_t pitch;int w,h,bottom;} KiCanvas;
static void Pixel(KiCanvas c,int x,int y,uint32 color){
  if(x<0||x>=c.w||y<32||y>=c.h||y>=c.bottom)return;
  color|=0xff000000;memcpy(c.p+y*c.pitch+x*4,&color,4);
}
static void Energy(KiCanvas c,int x,int y,int dir,int radius,int tail){
  for(int xx=-tail-radius;xx<=radius;++xx){int dx=xx<-tail?xx+tail:xx>0?xx:0;
    for(int yy=-radius;yy<=radius;++yy){int d=dx*dx+yy*yy;
      if(d<=radius*radius)Pixel(c,x+dir*xx,y+yy,d<radius*radius/2?0xf4ffff:0x37caff);
    }
  }
}
void KiDraw(uint8 *pixels,size_t pitch,int width,int height){
  KiCanvas c={pixels,pitch,width,height,height};
  int camera_x=mirror_current_layer1_xpos,camera_y=mirror_current_layer1_ypos;
  for(int k=0;k<pickup_count;++k){
    int cx=pickups[k].x+8,cy=pickups[k].y+8,r=7+((counter_global_frames>>3)&1);
    for(int y=-r;y<=r;++y)for(int x=-r;x<=r;++x)if(x*x+y*y<=r*r)
      Pixel(c,cx+x,cy+y,x*x+y*y>r*r-12?0xc57b1f:0xffe95b);
    const int stars[4][2]={{-3,-2},{2,-2},{-3,2},{2,2}};
    for(int i=0;i<4;++i){int x=cx+stars[i][0],y=cy+stars[i][1];Pixel(c,x,y,0xc72c27);Pixel(c,x+1,y,0xc72c27);}
  }
  if(timer_star_power && player_current_state!=9 && !player_hide_player_tile_flags){
    int px=(int16)(player_xpos-camera_x),py=(int16)(player_ypos-camera_y);
    for(int i=0;i<14;++i){int p=counter_global_frames+i*17,x=px-5+(i&1)*25+((p>>2)&3),y=py+30-p%40;
      for(int n=0;n<3+(p&3);++n)Pixel(c,x,y+n,i&1?0xffe15e:0xfff5ba);}
    if(charge){int dir=player_facing_direction?1:-1;
      Energy(c,px+8+dir*(8+Radius(charge)),HandY()-camera_y,dir,Radius(charge),0);}
  }
  if(wave.life){int tail=12+wave.power/2;if(tail>wave.travelled)tail=wave.travelled;
    Energy(c,(int16)(wave.x-camera_x),(int16)(wave.y-camera_y),wave.dir,Radius(wave.power),tail);}
  for(int i=0;i<impact_count && impact_life;++i){int x=impacts[i].x-camera_x,y=impacts[i].y-camera_y,d=19-impact_life;
    for(int n=0;n<8;++n)Pixel(c,x+((n&1)?d:-d)+(n/2)*2,y+((n&2)?d:-d),n&1?0xffffff:0x79e8ff);}
}
/* Native CHR helpers preserve the original Mario proportions. */

static void Decode16(const uint8 *data, uint8 pixels[16][16]) {
  for (int y = 0; y < 16; ++y) for (int x = 0; x < 16; ++x) {
    int p = (y >= 8 ? 64 : 0) + (x >= 8 ? 32 : 0) + 2 * (y & 7), bit = 7 - (x & 7);
    pixels[y][x] = ((data[p] >> bit) & 1) | (((data[p+1] >> bit) & 1) << 1) |
        (((data[p+16] >> bit) & 1) << 2) | (((data[p+17] >> bit) & 1) << 3);
  }
}
static void Encode16(const uint8 pixels[16][16], uint8 *data) {
  memset(data, 0, 128);
  for (int y = 0; y < 16; ++y) for (int x = 0; x < 16; ++x) {
    int p = (y >= 8 ? 64 : 0) + (x >= 8 ? 32 : 0) + 2 * (y & 7), bit = 7 - (x & 7), c = pixels[y][x];
    data[p] |= (c & 1) << bit; data[p+1] |= ((c >> 1) & 1) << bit;
    data[p+16] |= ((c >> 2) & 1) << bit; data[p+17] |= ((c >> 3) & 1) << bit;
  }
}
/* Native Mario tiles retain the original face, body scale and placement.
   The ki costume replaces his cap with bounded, pose-aligned Super Saiyan hair. */
static bool CapMaterial(int c) {return c==8 || c==9 || c==13;}
static int FormHeadPart(void) {
  int best=0,score=-1;
  for(int part=0;part<2;++part) {
    uint8 data[128],p[16][16];int n=0;
    SmwCopyFromVram(0x6000+part*0x20,data,64);SmwCopyFromVram(0x6100+part*0x20,data+64,64);Decode16(data,p);
    for(int y=0;y<16;++y) for(int x=0;x<16;++x) n+=p[y][x]==2;
    if(n>score) {score=n;best=part;}
  }
  return best;
}
static const char *kSaiyanHair[9]={
  "       s     s  ",
  "      sg    sg  ",
  "   s  sgg  sgg s",
  "   sgsghgsghggsg",
  " s sggghggghgggg",
  " sggghggghgggggs",
  "  sgghhggghgggs ",
  " sgggghhggghgs  ",
  "  ssggsssghggs  ",
};
static void SaiyanHair(uint8 pixels[16][16],const uint8 original[16][16],int face_top) {
  /* Hair stays inside the native 16px head. Eyes, nose and moustache retain
     their source pixels; no enlarged portrait and no detached head overlay. */
  if(face_top<4) return;
  int height=face_top<9?face_top:9;
  for(int y=0;y<face_top;++y) for(int x=0;x<16;++x) {
    if(original[y][x]==6 || original[y][x]==14) continue;
    pixels[y][x]=0;
    if(y<height) {
      char c=kSaiyanHair[y*9/height][x];
      pixels[y][x]=c=='s'?8:c=='g'?13:c=='h'?15:0;
    }
  }
}
void KiUploadPlayerGFX(void){
  if(!timer_star_power || misc_game_mode!=0x14)return;
  uint8 data[128],original[16][16],pixels[16][16];int head_part=FormHeadPart();
  for(int part=0;part<2;++part){
    SmwCopyFromVram(0x6000+part*0x20,data,64);SmwCopyFromVram(0x6100+part*0x20,data+64,64);
    Decode16(data,original);memcpy(pixels,original,sizeof(pixels));bool cap[16][16]={0};
    if(part==head_part){
      int queue[256],a=0,b=0;
      for(int y=0;y<10&&!b;++y)for(int x=0;x<16&&!b;++x)if(CapMaterial(original[y][x])){queue[b++]=y*16+x;cap[y][x]=true;}
      while(a<b){int i=queue[a++],x=i%16,y=i/16;const int dx[]={-1,1,0,0},dy[]={0,0,-1,1};
        for(int k=0;k<4;++k){int xx=x+dx[k],yy=y+dy[k];
          if(xx>=0&&xx<16&&yy>=0&&yy<16&&!cap[yy][xx]&&CapMaterial(original[yy][xx])){cap[yy][xx]=true;queue[b++]=yy*16+xx;}
        }
      }
    }
    int face_top=16;
    if(part==head_part)for(int y=0;y<16;++y)for(int x=0;x<16;++x)
      if((original[y][x]==6||original[y][x]==14)&&y<face_top)face_top=y;
    for(int y=0;y<16;++y)for(int x=0;x<16;++x){int c=original[y][x];
      if(c<8||c==14||c==15||cap[y][x])continue;
      pixels[y][x]=c==10?9:c==11?12:c==12?12:CapMaterial(c)?12:c;
      if(part!=head_part&&((y<=3&&x>=7&&x<=10)||(y>=7&&y<=8)))pixels[y][x]=10;
    }
    if(part==head_part)SaiyanHair(pixels,original,face_top);
    else{
      for(int y=10;y<16;++y)for(int x=0;x<16;++x)if(original[y][x]==3||original[y][x]==4||original[y][x]==5)pixels[y][x]=10;
      if(player_current_pose<16||player_current_pose==22||player_current_pose==63)
        for(int y=3;y<6;++y)for(int x=9;x<12;++x)if(original[y][x]>=8&&original[y][x]<=13)pixels[y][x]=x==10&&y==4?2:1;
    }
    Encode16(pixels,data);SmwCopyToVram(0x6000+part*0x20,data,64);SmwCopyToVram(0x6100+part*0x20,data+64,64);
  }
  uint16 palette[10];memcpy(palette,kPlayerPalettes+10*(player_current_character&1),sizeof(palette));
  palette[1]=0x7fff;palette[2]=0x0910;palette[3]=0x053a;palette[4]=0x3c41;palette[5]=0x64c2;
  palette[6]=0x0a9f;palette[7]=0x1b7f;palette[9]=0x3fff;RtlUpdatePalette(palette,0x86,10);
  static const uint8 slots[]={0x10,0xd4,0x10,0xe8};int start=slots[player_current_layer_priority&3];
  (get_OamEnt(oam_buf,start-8)+64)->ypos=(get_OamEnt(oam_buf,start-4)+64)->ypos=0xf0;
  CompressOamEntExt();
}
