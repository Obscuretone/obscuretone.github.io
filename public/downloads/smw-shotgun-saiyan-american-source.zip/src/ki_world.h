#ifndef SMW_KI_WORLD_H_
#define SMW_KI_WORLD_H_
#include "types.h"
void KiWorldSetEnabled(bool enabled);
bool KiWorldEnabled(void);
void KiWorldBeforeFrame(void);
void KiWorldBuildTiles(void);
#endif
