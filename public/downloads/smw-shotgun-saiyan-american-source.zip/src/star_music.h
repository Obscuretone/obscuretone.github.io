#ifndef SMW_STAR_MUSIC_H_
#define SMW_STAR_MUSIC_H_
#include "types.h"
bool StarMusicActive(void);
void StarMusicMix(int16 *samples,int frames,int channels,int rate);
#endif
