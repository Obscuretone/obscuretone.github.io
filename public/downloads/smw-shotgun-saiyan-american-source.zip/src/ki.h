#ifndef SMW_KI_H_
#define SMW_KI_H_
#include "types.h"
#include <stddef.h>
void KiReset(void);
void KiBeginFrame(void);
void KiTick(void);
void KiDraw(uint8 *pixels,size_t pitch,int width,int height);
void KiUploadPlayerGFX(void);
void KiRegisterPickup(int x,int y);
int KiChargeFrames(void);
int KiWaveSerial(void);
int KiWaveHits(void);
int KiWavePower(void);
#endif
