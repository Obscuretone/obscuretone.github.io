/* Eight-voice chiptune: warm pulse lead, triangle bass, chords and separate drums. */
#include "star_music.h"
#include "smw_rtl.h"
#include "variables.h"
#include <math.h>
#include <string.h>
#include "star_theme_notes.h"

enum { kVoices=8, kEchoSize=16384 };
static struct {double phase,end,start,hz,noise_low;int note,velocity;} voices[kVoices];
static double clock_ms,echo[kEchoSize][2],filtered[2];
static unsigned cursor,echo_pos,noise=0x2151a8e;
static int previous_star;
static const double kTau=6.283185307179586;

bool StarMusicActive(void){
  return misc_game_mode==0x14 && timer_star_power && player_current_state!=9;
}
static void Restart(void){
  clock_ms=0;cursor=echo_pos=0;
  memset(voices,0,sizeof(voices));memset(echo,0,sizeof(echo));
  memset(filtered,0,sizeof(filtered));
}
void StarMusicMix(int16 *samples,int frames,int channels,int rate){
  int star=timer_star_power;
  if(!StarMusicActive()){if(previous_star)Restart();previous_star=0;return;}
  if(!previous_star || star>previous_star+1)Restart();
  previous_star=star;
  if(flag_pause || rate<=0)return;
  const double filter=1-exp(-kTau*4200/rate);
  const unsigned delay_a=(unsigned)fmin(kEchoSize-1,rate*0.137);
  const unsigned delay_b=(unsigned)fmin(kEchoSize-1,rate*0.239);
  for(int i=0;i<frames;++i){
    if(clock_ms>=kThemeLoopMs){
      clock_ms-=kThemeLoopMs;cursor=0;memset(voices,0,sizeof(voices));
    }
    while(cursor<sizeof(kThemeNotes)/sizeof(kThemeNotes[0]) && kThemeNotes[cursor].start<=clock_ms){
      const struct ThemeNote *n=&kThemeNotes[cursor++];int v=n->voice;
      voices[v].start=n->start;voices[v].end=n->start+n->length;
      voices[v].note=n->note;voices[v].velocity=n->velocity;
      voices[v].hz=440*pow(2,(n->note-69)/12.0);voices[v].phase=0;
    }
    double mix[2]={0,0},send[2]={0,0};
    for(int v=0;v<kVoices;++v){
      if(clock_ms>=voices[v].end)continue;
      double age=(clock_ms-voices[v].start)/1000;
      double remaining=(voices[v].end-clock_ms)/1000;
      double env=fmin(1,age/0.008)*fmin(1,remaining/0.028);
      double p=voices[v].phase,w=kTau*p,value;
      double left=0.9,right=0.9;
      if(v==0){
        /* Only four harmonics: the melody stays clear without the harsh edge
           and aliasing of an unfiltered digital square wave. */
        value=(sin(w)+0.24*sin(3*w)+0.08*sin(5*w)+0.025*sin(7*w))*3200;
        env*=0.82+0.18*exp(-age*12);
      }else if(v==1){
        value=(4*fabs(p-0.5)-1)*2300;
      }else if(v<5){
        value=(sin(w)+0.18*sin(2*w)+0.08*sin(3*w))*1150;
        env*=0.25+0.75*exp(-age*7);
        left=v==2?0.95:v==3?0.65:0.4;
        right=v==2?0.4:v==3?0.65:0.95;
      }else{
        noise^=noise<<13;noise^=noise>>17;noise^=noise<<5;
        double n=((int)(noise&65535)-32768)/32768.0;
        voices[v].noise_low+=(n-voices[v].noise_low)*0.3;
        double high=n-voices[v].noise_low;
        env=fmin(1,age/0.001)*fmin(1,remaining/0.015);
        if(v==5){
          value=sin(kTau*(53*age+1.7*(1-exp(-age*40))))*4200*exp(-age*24);
          value+=high*450*exp(-age*170);
        }else if(v==6){
          if(voices[v].note>=41){
            double hz=voices[v].note>=47?180:120;
            value=sin(kTau*(hz*age+0.4*(1-exp(-age*30))))*2500*exp(-age*25);
          }else{
            value=(high*2300+sin(kTau*185*age)*750)*exp(-age*26);
          }
        }else{
          bool cymbal=voices[v].note>=49;
          value=high*(cymbal?780:850)*exp(-age*(cymbal?13:65));
          left=0.55;right=0.8;
        }
      }
      value*=env*voices[v].velocity/127.0;
      mix[0]+=value*left;mix[1]+=value*right;
      if(v<5){send[0]+=value*left;send[1]+=value*right;}
      double vibrato=v==0 && age>0.15?1+0.0018*sin(kTau*5.2*age):1;
      voices[v].phase+=voices[v].hz*vibrato/rate;
      voices[v].phase-=floor(voices[v].phase);
    }
    unsigned a=(echo_pos+kEchoSize-delay_a)%kEchoSize;
    unsigned b=(echo_pos+kEchoSize-delay_b)%kEchoSize;
    mix[0]+=echo[a][1]*0.12+echo[b][0]*0.06;
    mix[1]+=echo[a][0]*0.12+echo[b][1]*0.06;
    echo[echo_pos][0]=send[0];echo[echo_pos][1]=send[1];
    echo_pos=(echo_pos+1)%kEchoSize;
    for(int ch=0;ch<2;++ch)filtered[ch]+=(mix[ch]-filtered[ch])*filter;
    for(int ch=0;ch<channels;++ch){
      int value=samples[i*channels+ch]+(int)filtered[ch&1];
      samples[i*channels+ch]=value>32767?32767:value<-32768?-32768:value;
    }
    clock_ms+=1000.0/rate;
  }
}
