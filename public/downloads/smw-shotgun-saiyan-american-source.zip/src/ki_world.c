/* A separate native practice course for the publicly approved star power. */
#include "ki_world.h"
#include "shotgun.h"
#include "smw_rtl.h"
#include "variables.h"
#include "funcs.h"
#include "assets/smw_assets.h"
static bool enabled,entered,live;
typedef struct {uint16 x,y;uint8 id,rack;int slot;bool used;} Object;
static Object objects[]={
  {128,352,0x76,0,-1,0},{240,352,0xab,0,-1,0},{448,352,0xab,0,-1,0},{640,352,0xab,0,-1,0},
  {864,352,0x76,0,-1,0},
  {996,368,0x91,1,-1,0},{1020,368,0x91,1,-1,0},{1044,368,0x91,1,-1,0},{1068,368,0x91,1,-1,0},
  {996,320,0x91,1,-1,0},{1020,320,0x91,1,-1,0},{1044,320,0x91,1,-1,0},{1068,320,0x91,1,-1,0}
};
void KiWorldSetEnabled(bool value){enabled=value;entered=live=false;}
bool KiWorldEnabled(void){return enabled;}
static void Tile(int x,int y,int tile){
  int p=(x>>4)*432+y*16+(x&15);blocks_map16_table_lo[p]=tile;blocks_map16_table_hi[p]=tile>>8;
}
void KiWorldBuildTiles(void){
  if(!enabled)return;
  misc_screens_in_lvl=camera_last_screen_horiz=5;camera_last_screen_vert=1;flag_layer1_vert_scroll_level_setting=1;
  for(int x=0;x<80;++x)for(int y=0;y<27;++y)Tile(x,y,y==24?0x100:y>24?0x3f:0x25);
  for(int x=61;x<70;++x)Tile(x,21,0x130);
  for(unsigned i=0;i<sizeof(objects)/sizeof(objects[0]);++i){objects[i].slot=-1;objects[i].used=false;}
}
void KiWorldBeforeFrame(void){
  if(!enabled)return;
  if((io_controller_press1&0x20)&&misc_game_mode==0x14){entered=live=false;}
  if(!entered){
    InitializeFirst8KBOfRAM();waiting_for_vblank=1;player_current_life_count=98;
    misc_game_mode=0x11;misc_intro_level_flag=5;ow_players_map[0]=1;counter_sublevels_entered=0;
    mirror_mosaic_size_and_bgenable=0xf0;HandleSPCUploads_StrtSPCMscUpld(kSpcLevelMusicBank);
    entered=true;live=false;ShotgunReset();return;
  }
  if(misc_game_mode!=0x14)return;
  if(!live){
    if(mirror_mosaic_size_and_bgenable&0xf0)return;
    for(int k=0;k<12;++k)spr_current_status[k]=0;
    player_xpos=16;player_ypos=352;player_current_power_up=1;player_current_state=0;
    player_xspeed=player_yspeed=0;timer_star_power=0;timer_player_hurt=0;live=true;
  }
  if(flag_pause||flag_sprites_locked)return;
  counter_timer_hundreds=counter_timer_tens=counter_timer_ones=9;
  for(unsigned i=0;i<sizeof(objects)/sizeof(objects[0]);++i){Object *o=&objects[i];int k=o->slot;
    if(k>=0&&(!spr_current_status[k]||spr_spriteid[k]!=o->id)){o->used=true;o->slot=-1;k=-1;}
    int sx=(int16)(o->x-mirror_current_layer1_xpos);
    if(k<0&&!o->used&&sx>=-16&&sx<248){
      for(k=0;k<12&&spr_current_status[k];++k){}if(k==12)continue;
      spr_spriteid[k]=o->id;InitializeNormalSpriteRAMTables(k);spr_current_status[k]=8;
      spr_load_status_table_index[k]=0xff;SetSprXYPos(k,o->x,o->y);spr_table157c[k]=1;
      if(o->id==0x91){spr_table00c2[k]=0;spr_table1570[k]=0;}
      o->slot=k;
    }
    if(k>=0&&spr_current_status[k]==8&&(o->rack||o->id==0x76)){
      SetSprXYPos(k,o->x,o->y);spr_xspeed[k]=spr_yspeed[k]=0;
      if(o->rack)spr_decrementing_table1540[k]=80;
      else spr_decrementing_table1540[k]=spr_decrementing_table154c[k]=0;
    }
  }
}
