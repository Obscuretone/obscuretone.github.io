/* Shotgun mod for snesrev/smw. Original pixel art and synthesized sound. */
#include "shotgun.h"
#include "smw_rtl.h"
#include "variables.h"
#include "funcs.h"
#include "ki.h"
#include "star_music.h"
#include <math.h>
#include <stdatomic.h>
#include <string.h>
#include <stdlib.h>

enum { kRange = 96, kCooldown = 28, kParticleCount = 384 };
enum { kBlood, kSmoke, kPellet, kShell };
typedef struct Particle {
  float x, y, vx, vy;
  uint8 life, kind, size;
  uint32 color;
} Particle;
static Particle particles[kParticleCount];
static unsigned particle_cursor, random_state = 0x51a7f00d;
static int cooldown, flash, shot_x, shot_y, shot_dir, shot_origin_x, last_mode;
static bool start_armed, reserve_drawn;
static struct { int x, y, emerge; } pickups[12];
static int pickup_count;
static atomic_uint sound_event;
static unsigned hit_mask;
static struct { int distance, previous; bool active; } blast;
static void AdvanceBlast(void);
unsigned ShotgunShotSerial(void) { return atomic_load(&sound_event); }
unsigned ShotgunHitMask(void) { return hit_mask; }
int ShotgunBlastDistance(void) { return blast.active ? blast.distance : 0; }
uint8 ShotgunPlayerPose(uint8 pose) {
  /* Recoil can oppose the held direction without throwing the arm upward. */
  return cooldown && player_current_power_up==3 && !timer_star_power && pose==13 ? 0 : pose;
}
static void HandGrip(int *x, int *y);

static unsigned Random(void) {
  random_state ^= random_state << 13;
  random_state ^= random_state >> 17;
  random_state ^= random_state << 5;
  return random_state;
}
static void Emit(float x, float y, float vx, float vy, int kind, int life, uint32 color, int size) {
  Particle *p = &particles[particle_cursor++ % kParticleCount];
  *p = (Particle){x, y, vx, vy, life, kind, size, color};
}
void ShotgunSetStartArmed(bool armed) { start_armed = armed; }
void ShotgunReset(void) {
  memset(particles, 0, sizeof(particles));
  particle_cursor = cooldown = flash = pickup_count = 0;
  hit_mask=0;
  reserve_drawn = false;
  last_mode = -1;
  atomic_store(&sound_event, 0);
  memset(&blast,0,sizeof(blast));KiReset();
}
void ShotgunRegisterPickup(int x, int y, int emerge) {
  if (pickup_count < 12) {
    pickups[pickup_count].x = x;
    pickups[pickup_count].emerge = emerge;
    pickups[pickup_count++].y = y;
  }
}
void ShotgunRegisterReserve(void) { reserve_drawn = true; }
void ShotgunUploadPlayerGFX(void) { KiUploadPlayerGFX(); }

static bool InLevel(void) { return misc_game_mode == 0x14; }
static int PlayerGunY(void) {
  return (int)player_ypos + (player_ducking_flag ? 27 : 21) +
      (player_riding_yoshi_flag ? (yoshi_ducking_flag ? 12 : 4) : 0);
}
void ShotgunTick(void) {
  hit_mask=0;
  pickup_count = 0;
  KiBeginFrame();
  reserve_drawn = false;
  if (!InLevel()) {
    memset(particles, 0, sizeof(particles));
    cooldown = flash = 0;
    blast.active=false;KiReset();
  } else {
    if (last_mode != 0x14 && start_armed)
      player_current_power_up = 3;
    if (!flag_sprites_locked && !flag_pause) {
      KiTick();AdvanceBlast();
      if (cooldown) --cooldown;
      if (cooldown == 16) {
        int x,y;HandGrip(&x,&y);
        Emit(x+mirror_current_layer1_xpos,y+mirror_current_layer1_ypos-3,
            -shot_dir*1.5f,-2.6f,kShell,66,0xe73c32,3);
      }
      if (flash) --flash;
      for (unsigned i = 0; i < kParticleCount; ++i) {
        Particle *p = &particles[i];
        if (!p->life) continue;
        --p->life;
        p->x += p->vx;
        p->y += p->vy;
        if (p->kind == kBlood || p->kind == kShell) p->vy += 0.16f;
        if (p->kind == kSmoke) { p->vx *= 0.95f; p->vy -= 0.012f; }
      }
    }
  }
  last_mode = misc_game_mode;
}

/* Explicit hostile IDs: platforms, Yoshi, dolphins, keys and goal objects survive. */
bool ShotgunIsHostile(unsigned id) {
  if (id <= 0x18) return id != 0x0e && id != 0x12;
  if (id >= 0x1a && id <= 0x20) return true;
  if (id >= 0x22 && id <= 0x2b) return true;
  if (id >= 0x30 && id <= 0x34) return true;
  if (id >= 0x37 && id <= 0x3d) return true;
  if (id == 0x2e || id == 0x3f || id == 0x40 || id == 0x44) return true;
  if (id >= 0x46 && id <= 0x48) return true;
  if (id >= 0x4b && id <= 0x51) return true;
  if (id >= 0x64 && id <= 0x68) return true;
  if (id >= 0x6e && id <= 0x73) return true;
  if (id == 0x86 || id == 0x90) return true;
  if (id >= 0x91 && id <= 0x9b) return true;
  if (id >= 0x9d && id <= 0xb0) return true;
  if (id >= 0xb2 && id <= 0xb6) return true;
  return id == 0xbc || id == 0xbd || id == 0xbe || id == 0xbf ||
         id == 0xc2 || id == 0xc3 || id == 0xc5;
}

static bool HitBox(int x, int y, int w, int h) {
  /* All calculations use signed wrapped world deltas, including page crossings. */
  int dx = (int16)(x - shot_origin_x), dy = (int16)(y - shot_y);
  int near = shot_dir > 0 ? dx : -dx - w;
  int far = near + w;
  if (far < blast.previous || near > blast.distance || near > kRange) return false;
  int distance = far < blast.distance ? far : blast.distance;
  int spread = 10 + distance / 5;
  return dy <= spread && dy + h >= -spread;
}
static bool VisibleBox(int x, int y, int w, int h) {
  int sx = (int16)(x - mirror_current_layer1_xpos);
  int sy = (int16)(y - mirror_current_layer1_ypos);
  return sx + w >= 0 && sx < 256 && sy + h >= 32 && sy < 224;
}
static void BloodBurst(int x, int y) {
  static const uint32 colors[] = {0xf03438, 0xc51f2f, 0x951625, 0x6a1624};
  for (int n = 0; n < 24; ++n) {
    float speed = 0.4f + (Random() & 63) * 0.045f;
    float vy = ((int)(Random() % 100) - 75) * 0.045f;
    Emit(x, y, shot_dir * speed, vy, kBlood, 48 + Random() % 36,
         colors[n & 3], n < 7 ? 2 : 1);
  }
  for (int n = 0; n < 4; ++n)
    Emit(x, y, shot_dir * (1 + n * 0.5f), -1.0f, kSmoke, 18, 0xd2c4b0, 2);
}

bool ShotgunBossDying(int k) {
  unsigned id = spr_spriteid[k];
  if (id == 0xa0) return spr_table151c[k] >= 4 && spr_table151c[k] <= 6;
  if (id == 0xa9) return spr_table151c[k] != 0;
  if (id == 0xc5) return spr_table00c2[k] == 6;
  if (id == 0x29) {
    if (spr_table00c2[k] >= 5) return spr_table151c[k] >= 5;
    if (spr_table00c2[k] >= 3) return spr_decrementing_table163e[k] != 0;
    return spr_table151c[k] >= 4;
  }
  return false;
}
void ShotgunDefeat(int k) {
  unsigned id = spr_spriteid[k];
  if (id == 0xa0) {
    /* Use Bowser's final defeat sequence so Peach and the ending still run. */
    spr_table151c[k] = 4;
    spr_yspeed[k] = (uint8)-32;
    spr_xspeed[k] = 0;
    spr_decrementing_table1540[k] = 0;
  } else if (id == 0xa9) {
    spr_table151c[k] = 1;
    spr_current_status[k] = 2;
    spr_yspeed[k] = (uint8)-48;
  } else if (id == 0xc5) {
    spr_table00c2[k] = 6;
    spr_decrementing_table1540[k] = 0;
  } else if (id == 0x29) {
    /* Koopalings have three different engines. Let their own exit logic run. */
    if (spr_table00c2[k] >= 5 && spr_table1570[k]) {
      spr_current_status[k] = 0; /* Lemmy/Wendy decoy. */
    } else if (spr_table00c2[k] >= 5) {
      spr_table151c[k] = 5;
      spr_yspeed[k] = 0;
    } else if (spr_table00c2[k] < 3) {
      spr_table151c[k] = 4;
      spr_decrementing_table1540[k] = 19;
    } else {
      spr_decrementing_table163e[k] = 80; /* Iggy/Larry's native exit timer. */
    }
  } else {
    spr_current_status[k] = 0;
    /* Keep this instance dead when the camera moves away and returns. */
    if (spr_load_status_table_index[k] != 0xff)
      sprites_load_status[spr_load_status_table_index[k]] = 1;
  }
}

bool ShotgunFire(void) {
  if (!InLevel() || timer_star_power || player_current_power_up != 3 || player_current_state ||
      flag_sprites_locked || flag_pause || cooldown) return false;
  cooldown = kCooldown;
  flash = 6;
  shot_dir = player_facing_direction ? 1 : -1;
  shot_origin_x = player_xpos + 8;
  int gx,gy;HandGrip(&gx,&gy);
  shot_x = gx + mirror_current_layer1_xpos + shot_dir*12;
  shot_y = gy + mirror_current_layer1_ypos - 4;
  /* The spread starts at the muzzle and travels, rather than killing on input. */
  blast.distance=(shot_x-shot_origin_x)*shot_dir;blast.previous=0;blast.active=true;
  /* The fireball pose thrusts the glove forward; a shouldered gun stays put. */
  timer_display_player_shoot_fireball_pose = 0;
  player_xspeed = (uint8)(-shot_dir * 18);
  atomic_fetch_add(&sound_event, 1);
  for (int n = 0; n < 8; ++n)
    Emit(shot_x, shot_y, shot_dir * (0.5f + n * 0.2f), -0.4f - n * 0.1f,
         kSmoke, 16 + n, 0xc4bfb2, 2);
  return true;
}
static void AdvanceBlast(void) {
  if(!blast.active) return;
  if(blast.distance>=kRange) {blast.active=false;return;}
  blast.previous=blast.distance;
  blast.distance+=12;if(blast.distance>kRange) blast.distance=kRange;
  for (int k = 0; k < 12; ++k) {
    if (spr_current_status[k] < 8 || spr_current_status[k] > 10 ||
        !ShotgunIsHostile(spr_spriteid[k]) || ShotgunBossDying(k)) continue;
    if (spr_spriteid[k] == 0x9d && spr_table00c2[k] == 3) continue;
    CollInfo ci = {0};
    StandardSpriteToSpriteCollisionChecks_GetSpriteClippingA(k, &ci);
    int x = PAIR16(ci.r10, ci.r4), y = PAIR16(ci.r11, ci.r5);
    if (!VisibleBox(x, y, ci.r6, ci.r7) || !HitBox(x, y, ci.r6, ci.r7)) continue;
    BloodBurst(x + ci.r6 / 2, y + ci.r7 / 2);
    hit_mask|=1u<<k;
    ShotgunDefeat(k);
  }
  for (int k = 0; k < 10; ++k) {
    int id = ext_spr_spriteid[k];
    if (!(id == 2 || id == 3 || id == 4 || id == 6 || id == 11 || id == 12 || id == 13)) continue;
    int x = PAIR16(ext_spr_xpos_hi[k], ext_spr_xpos_lo[k]);
    int y = PAIR16(ext_spr_ypos_hi[k], ext_spr_ypos_lo[k]);
    if (VisibleBox(x, y, 8, 8) && HitBox(x, y, 8, 8)) {
      BloodBurst(x + 4, y + 4);
      ext_spr_spriteid[k] = 0;
    }
  }
  for (int k = 0; k < 20; ++k) {
    int id = cluster_spr_spriteid[k];
    if (!(id == 3 || id == 4 || id == 6 || id == 7 || id == 8)) continue;
    int x = PAIR16(cluster_spr_xpos_hi[k], cluster_spr_xpos_lo[k]);
    int y = PAIR16(cluster_spr_ypos_hi[k], cluster_spr_ypos_lo[k]);
    if (VisibleBox(x, y, 16, 16) && HitBox(x, y, 16, 16)) {
      BloodBurst(x + 8, y + 8);
      cluster_spr_spriteid[k] = 0;
    }
  }
}

typedef struct Canvas { uint8 *p; size_t pitch; int w, h, top, bottom; } Canvas;
static void Rect(Canvas c, int x, int y, int w, int h, uint32 rgb) {
  for (int yy = y; yy < y + h; ++yy) {
    if (yy < c.top || yy >= c.h || yy>=c.bottom) continue;
    for (int xx = x; xx < x + w; ++xx) {
      if (xx < 0 || xx >= c.w) continue;
      uint32 color = 0xff000000u | rgb;
      memcpy(c.p + yy * c.pitch + xx * 4, &color, 4);
    }
  }
}
static void Gun(Canvas c, int x, int y, int dir, int recoil) {
  /* 23 by 9, drawn in local pixels so facing and recoil stay crisp. */
  static const char *art[] = {
    "         oooooooooooooo",
    "   oooooossssssssssssooo",
    "ooottttttgggggggggggggo",
    "ottttttttgggggggggggggo",
    "ottttttoooowwwwwwwooooo",
    " ootttoo  obboooooo     ",
    "  oooo    obbo          ",
    "          oo           "
  };
  for (int row = 0; row < 8; ++row) {
    for (int col = 0; art[row][col]; ++col) {
      uint32 color;
      switch (art[row][col]) {
      case 'o': color = 0x27202c; break;
      case 's': color = 0xc3c7cd; break;
      case 'g': color = 0x697581; break;
      case 't': color = 0xa65c38; break;
      case 'w': color = 0xd88742; break;
      case 'b': color = 0x70432e; break;
      default: continue;
      }
      Rect(c, x + dir * (col - recoil), y + row - 3, 1, 1, color);
    }
  }
}
static void HandGrip(int *x, int *y) {
  static const uint8 slots[]={0x10,0xd4,0x10,0xe8};
  int start=slots[player_current_layer_priority&3],index=(start>>2)+65;
  OamEnt *o=get_OamEnt(oam_buf,start)+65;
  int bx=o->xpos+((sprites_oamtile_size_buffer[index]&1)<<8);if(bx>=256) bx-=512;
  int dir=player_facing_direction?1:-1;
  *x=(int16)(player_xpos-mirror_current_layer1_xpos)+8+dir*3;
  *y=PlayerGunY()-mirror_current_layer1_ypos;
  if(o->ypos>=224 || o->charnum>0x20 ||
      abs(bx-(int16)(player_xpos-mirror_current_layer1_xpos))>20 ||
      abs(o->ypos-(int16)(player_ypos-mirror_current_layer1_ypos))>48) return;
  uint8 data[128];int address=0x6000+(o->charnum>>4)*0x100+(o->charnum&15)*16;
  SmwCopyFromVram(address,data,64);SmwCopyFromVram(address+0x100,data+64,64);
  int edge=-999;
  for(int yy=0;yy<12;++yy) for(int xx=0;xx<16;++xx) {
    int p=(yy>=8?64:0)+(xx>=8?32:0)+2*(yy&7),bit=7-(xx&7);
    int c=((data[p]>>bit)&1)|(((data[p+1]>>bit)&1)<<1)|(((data[p+16]>>bit)&1)<<2)|(((data[p+17]>>bit)&1)<<3);
    int sx=o->flags&0x40?15-xx:xx;
    if(c==1 && sx*dir>edge) edge=sx*dir;
  }
  int total=0,sum_x=0,sum_y=0;
  for(int yy=0;yy<12;++yy) for(int xx=0;xx<16;++xx) {
    int p=(yy>=8?64:0)+(xx>=8?32:0)+2*(yy&7),bit=7-(xx&7);
    int c=((data[p]>>bit)&1)|(((data[p+1]>>bit)&1)<<1)|(((data[p+16]>>bit)&1)<<2)|(((data[p+17]>>bit)&1)<<3);
    int sx=o->flags&0x40?15-xx:xx,sy=o->flags&0x80?15-yy:yy;
    if(c==1 && sx*dir>=edge-2) {sum_x+=sx;sum_y+=sy;++total;}
  }
  if(total>=2) {*x=bx+(sum_x+total/2)/total;*y=o->ypos+(sum_y+total/2)/total;}
}
/* Keep the real animated glove pixels in front of the held weapon. */
static int SaveGloves(Canvas c,int xy[256][2],uint32 colors[256]) {
  static const uint8 slots[]={0x10,0xd4,0x10,0xe8};int start=slots[player_current_layer_priority&3];
  OamEnt *o=get_OamEnt(oam_buf,start)+65;int index=(start>>2)+65;
  int bx=o->xpos+((sprites_oamtile_size_buffer[index]&1)<<8);if(bx>=256)bx-=512;
  if(o->ypos>=224 || o->charnum>0x20)return 0;
  uint8 data[128],tile[16][16];int address=0x6000+(o->charnum>>4)*256+(o->charnum&15)*16;
  SmwCopyFromVram(address,data,64);SmwCopyFromVram(address+256,data+64,64);
  for(int y=0;y<16;++y)for(int x=0;x<16;++x){int p=(y>=8?64:0)+(x>=8?32:0)+2*(y&7),bit=7-(x&7);
    tile[y][x]=((data[p]>>bit)&1)|(((data[p+1]>>bit)&1)<<1)|(((data[p+16]>>bit)&1)<<2)|(((data[p+17]>>bit)&1)<<3);}
  int count=0;
  for(int y=0;y<12;++y)for(int x=0;x<16;++x){bool hand=tile[y][x]==1;
    if(tile[y][x]==3)for(int yy=y-1;yy<=y+1;++yy)for(int xx=x-1;xx<=x+1;++xx)
      if(xx>=0&&xx<16&&yy>=0&&yy<12&&tile[yy][xx]==1)hand=true;
    int sx=bx+((o->flags&0x40)?15-x:x),sy=o->ypos+((o->flags&0x80)?15-y:y);
    if(hand&&sx>=0&&sx<c.w&&sy>=32&&sy<c.h){xy[count][0]=sx;xy[count][1]=sy;memcpy(&colors[count],c.p+sy*c.pitch+sx*4,4);++count;}
  }
  return count;
}
void ShotgunDraw(uint8 *pixels, size_t pitch, int width, int height) {
  if (!InLevel()) return;
  Canvas c = {pixels, pitch, width, height, 32, height};
  int camera_x = mirror_current_layer1_xpos, camera_y = mirror_current_layer1_ypos;
  for (int n = 0; n < pickup_count; ++n) {
    Canvas item=c;int y=pickups[n].y+3;
    if(pickups[n].emerge) {
      int edge=pickups[n].y+(64-pickups[n].emerge)/4-1;
      for(int k=0;k<12;++k) if(spr_current_status[k] && spr_table00c2[k] &&
          (spr_spriteid[k]==0x83 || spr_spriteid[k]==0x84)) {
        OamEnt *b=get_OamEnt(oam_buf,spr_oamindex[k])+64;
        int dx=(int16)(GetSprXPos(k)-camera_x)-pickups[n].x;
        if(dx>=-8 && dx<=8 && b->ypos<224 && abs((int)b->ypos-edge)<=16) edge=b->ypos;
      }
      item.bottom=edge<item.bottom?edge:item.bottom;
    }
    Gun(item,pickups[n].x-3,y,1,0);
  }
  if (reserve_drawn) {
    Canvas hud = c; hud.top = 0;
    Gun(hud, 116, 21, 1, 0);
  }
  bool visible = player_current_power_up == 3 && !timer_star_power && player_current_state != 9 &&
      !player_hide_player_tile_flags && (!timer_player_hurt || (counter_global_frames & 2));
  int muzzle_x=0,muzzle_y=0,muzzle_dir=shot_dir;
  if (visible) {
    int dir = player_facing_direction ? 1 : -1;
    int gx,gy;HandGrip(&gx,&gy);
    muzzle_x=gx+dir*12;muzzle_y=gy-4;muzzle_dir=dir;
    int hand_xy[256][2];uint32 hand_colors[256];int hand_count=SaveGloves(c,hand_xy,hand_colors);
    Gun(c,gx-dir*10,gy-3,dir,0);
    for(int i=0;i<hand_count;++i)memcpy(c.p+hand_xy[i][1]*c.pitch+hand_xy[i][0]*4,&hand_colors[i],4);
  }
  if(blast.active) {
    int distance=blast.distance,spread=10+distance/5;
    int x=(int16)(shot_origin_x+shot_dir*distance-camera_x),y=(int16)(shot_y-camera_y);
    for(int n=-4;n<=4;++n) {
      int yy=y+n*spread/4;
      Rect(c,x-shot_dir*5,yy-1,6,3,0x6c321f);
      Rect(c,x-shot_dir*4,yy,5,2,0xffd24a);
      Rect(c,x,yy,2,1,0xffffed);
    }
  }
  for (unsigned n = 0; n < kParticleCount; ++n) {
    Particle *p = &particles[n];
    if (!p->life) continue;
    int x = (int16)((int)p->x - camera_x), y = (int16)((int)p->y - camera_y);
    if (p->kind == kPellet) {
      Rect(c, x - shot_dir * 3, y, 4, 1, p->color);
    } else if (p->kind == kShell) {
      bool horizontal = (p->life & 4) != 0;
      Rect(c,x-1,y-1,horizontal?8:5,horizontal?5:8,0x38232b);
      Rect(c,x,y,horizontal?6:3,horizontal?3:6,p->color);
      Rect(c,x,y,horizontal?2:3,horizontal?3:2,0xffdc72);
    } else {
      Rect(c, x, y, p->size, p->size, p->color);
    }
  }
  if (flash && visible) {
    /* Follow the held muzzle while Mario recoils; pellets stay in world space. */
    int x=muzzle_x,y=muzzle_y;
    int length = flash >= 4 ? 24 : 12;
    for (int i = 0; i < length; ++i) {
      int r = (length - i) / 4 + ((i + flash) % 3);
      Rect(c, x + muzzle_dir * i, y - r, 1, 2 * r + 1, 0xf58c37);
      if (r > 1) Rect(c, x + muzzle_dir * i, y - r / 2, 1, r + 1, 0xffe7a0);
      if (i < length / 2) Rect(c, x + muzzle_dir * i, y - 1, 1, 3, 0xfff9df);
    }
  }
  KiDraw(pixels,pitch,width,height);
}

void ShotgunMixAudio(int16 *samples, int frames, int channels, int rate) {
  StarMusicMix(samples,frames,channels,rate);
  static unsigned seen, noise = 0x7135;
  static int position = -1;
  unsigned event = atomic_load(&sound_event);
  if (event != seen) { seen = event; position = event ? 0 : -1; }
  if (position < 0 || rate <= 0) return;
  for (int i = 0; i < frames; ++i, ++position) {
    float t = (float)position / rate;
    if (t > 0.40f) { position = -1; break; }
    noise ^= noise << 13; noise ^= noise >> 17; noise ^= noise << 5;
    float n = ((int)(noise & 65535) - 32768) / 32768.0f;
    float value = 13500 * n * expf(-t * 38) +
        12500 * sinf(6.2831853f * (90 * t - 70 * t * t)) * expf(-t * 30);
    /* Two brief metallic pump clicks after the initial blast. */
    if (t > 0.19f && t < 0.22f) value += n * 3300 * (0.22f - t) / 0.03f;
    if (t > 0.29f && t < 0.32f) value += n * 4000 * (0.32f - t) / 0.03f;
    for (int ch = 0; ch < channels; ++ch) {
      int v = samples[i * channels + ch] + (int)value;
      samples[i * channels + ch] = v > 32767 ? 32767 : v < -32768 ? -32768 : v;
    }
  }
}
