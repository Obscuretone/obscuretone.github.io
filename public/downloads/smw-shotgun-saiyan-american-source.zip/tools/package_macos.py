#!/usr/bin/env python3
"""Package a compiled native build with SDL2. Run from any directory."""
import pathlib
import plistlib
import shutil
import subprocess
import sys
import tempfile

root = pathlib.Path(__file__).resolve().parent.parent
destination = pathlib.Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root.parent / 'Super Mario World Shotgun.app'
# Sign away from Finder/iCloud metadata, which can attach a resource fork to app folders.
staging = tempfile.TemporaryDirectory(prefix='smw-shotgun-package-')
app = pathlib.Path(staging.name) / destination.name
contents = app / 'Contents'
macos, resources, frameworks = (contents / p for p in ('MacOS', 'Resources', 'Frameworks'))
for folder in (macos, resources, frameworks):
    folder.mkdir(parents=True, exist_ok=True)
subprocess.run(['make', '-j8', 'smw'], cwd=root, check=True, stdout=subprocess.DEVNULL)
for name in ('smw', 'smw.ini', 'smw_assets.dat', 'LICENSE.txt', 'SHOTGUN.md'):
    shutil.copy2(root / name, resources / name)
prefix = subprocess.check_output(['sdl2-config', '--prefix'], text=True).strip()
library = pathlib.Path(prefix) / 'lib/libSDL2-2.0.0.dylib'
shutil.copy2(library.resolve(), frameworks / library.name)
(frameworks / library.name).chmod(0o644)
shutil.copy2(library.resolve().parent.parent / 'LICENSE.txt', resources / 'SDL2-LICENSE.txt')
subprocess.run(['clang', str(root / 'tools/macos_launcher.c'), '-O2', '-o', str(macos / 'launch')], check=True)
subprocess.run(['install_name_tool', '-change', str(library), '@executable_path/../Frameworks/' + library.name,
                str(resources / 'smw')], check=True)
# Homebrew may use an opt path different from the resolved prefix.
deps = subprocess.check_output(['otool', '-L', str(resources / 'smw')], text=True)
for line in deps.splitlines()[1:]:
    path = line.strip().split(' (')[0]
    if 'libSDL2' in path and not path.startswith('@'):
        subprocess.run(['install_name_tool', '-change', path, '@executable_path/../Frameworks/' + library.name,
                        str(resources / 'smw')], check=True)
subprocess.run(['install_name_tool', '-id', '@executable_path/../Frameworks/' + library.name,
                str(frameworks / library.name)], check=True)
info = dict(CFBundleExecutable='launch', CFBundleIdentifier='local.smw.shotgun',
            CFBundleName='Super Mario World Shotgun', CFBundleDisplayName='Super Mario World Shotgun',
            CFBundleVersion='1', CFBundleShortVersionString='1.0', CFBundlePackageType='APPL',
            NSHighResolutionCapable=True, NSHumanReadableCopyright='snesrev and contributors; shotgun mod 2026')
(contents / 'Info.plist').write_bytes(plistlib.dumps(info))
subprocess.run(['xattr', '-cr', str(app)], check=True)
subprocess.run(['codesign', '--force', '--sign', '-', str(frameworks / library.name)], check=True)
subprocess.run(['codesign', '--force', '--sign', '-', str(resources / 'smw')], check=True)
subprocess.run(['codesign', '--force', '--sign', '-', str(app)], check=True)
subprocess.run(['codesign', '--verify', '--deep', '--strict', str(app)], check=True)
subprocess.run(['ditto', '-c', '-k', '--keepParent', '--norsrc', '--noextattr', '--noqtn',
                str(app), str(destination.with_suffix('.zip'))], check=True)
if destination.exists():
    previous = destination / 'Contents/Info.plist'
    if not previous.exists() or plistlib.loads(previous.read_bytes()).get('CFBundleIdentifier') != 'local.smw.shotgun':
        raise SystemExit('Refusing to replace an unrelated app: ' + str(destination))
    shutil.rmtree(destination)
def copy_clean(source, target):
    shutil.copyfile(source, target)
    shutil.copymode(source, target)
    return target
shutil.copytree(app, destination, copy_function=copy_clean)
subprocess.run(['codesign', '--verify', '--deep', '--strict', str(destination)], check=True)
print(destination)
staging.cleanup()
