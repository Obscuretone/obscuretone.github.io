#define SMW_CAPTURE_MAIN
#include "headless.c"
#include "src/star_music.h"
static long Energy(const int16 *p,int n){long e=0;for(int i=0;i<n;++i)e+=abs(p[i]);return e;}
int main(void){
  assert(SDL_Init(0)==0);g_audio_mutex=SDL_CreateMutex();LoadAssets();assert(SnesInit(NULL,0));
  g_snes_width=256;g_snes_height=224;g_spc_player=SmwSpcPlayer_Create();g_spc_player->initialize(g_spc_player);
  PpuBeginDrawing(g_snes->ppu,g_pixels,1024,0);PpuBeginDrawing(g_my_ppu,g_my_pixels,1024,0);
  ShotgunSetStartArmed(false);for(int n=0;n<500;++n)Frame(n%100==0?0x108:0);LoadYoshisIsland1();
  GivePlayerStarPower();for(int n=0;n<90;++n)Frame(0);
  int16 a[534*2]={0};RtlRenderAudio(a,534,2);long quiet=Energy(a,1068);
  assert(quiet<1068*8);
  io_sound_ch3=1;Frame(0);Frame(0);RtlRenderAudio(a,534,2);long effect=Energy(a,1068);
  assert(effect>quiet+1000);
  int16 phrase[32000*2]={0};StarMusicMix(phrase,32000,2,32000);assert(Energy(phrase,64000)>100000);
  flag_pause=1;memset(a,0,sizeof(a));StarMusicMix(a,534,2,32000);assert(!Energy(a,1068));flag_pause=0;
  timer_star_power=31;for(int n=0;n<9;++n)Frame(0);
  timer_star_power=0;Frame(0);assert(g_spc_player->port_to_snes[2]==(misc_music_register_backup&0x3f));
  memset(a,0,sizeof(a));StarMusicMix(a,534,2,32000);assert(!Energy(a,1068));
  printf("PASS: native star music muted (%ld), native SFX retained (%ld), chiptune audible, pause and expiry honored\n",quiet,effect);
  return 0;
}
