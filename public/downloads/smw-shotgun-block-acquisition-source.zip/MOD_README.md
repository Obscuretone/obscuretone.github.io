# Super Mario World shotgun modification

Base: snesrev/smw commit eae20c65c58930c8b62c76188d259579ad4130f1 (MIT).
Clone that revision, extract this kit into it and run `git apply shotgun.patch`.
Install SDL2, a C compiler and Make. Follow SHOTGUN.md for game resource extraction.
Run `make -j8`, then `./smw`. Mario starts unarmed: hit the flower variant of the
flying question block and touch the released shotgun to acquire it. The block
supplies the shotgun at either player size. The Mac launcher uses this progression.
The optional `./smw --shotgun-start` flag remains available for testing.
`make test` runs the integration suite, including small-Mario acquisition and
no leftover world-pickup drawing after consumption.
`make tests/record` builds the continuous gameplay recorder.
`./tests/record /absolute/output/directory` writes game.bgra, game.s16le and events.jsonl.
Video is 256x224 BGRA at 16000/267 fps; audio is 32 kHz stereo s16le.
The recorder logs the block hit, live shotgun pickup, actual collection and kills.
It asserts that a real pickup is consumed on acquisition and no shot occurs before it.
It uploads the level SPC bank and starts the header-selected music.
The mod uses a 96-pixel range, a lowered gun and regular Mario colors.
No game ROM or extracted game asset bundle is included.
