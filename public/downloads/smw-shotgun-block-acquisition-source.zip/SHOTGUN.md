# Super Mario World: Shotgun

A native Mac mod of the actual reverse-engineered Super Mario World game.

## Play

Open **Super Mario World Shotgun.app**. The bundled Mac build is for Apple Silicon and includes SDL2; an emulator is unnecessary.

- **Enter:** start / confirm menu selections
- **Arrow keys:** move / aim left or right
- **Z:** jump
- **X:** spin jump
- **A or S:** shoot / run (SNES Y or X)
- **P:** pause
- **Alt + Enter:** full screen

Mario starts unarmed. The flower variant of the flying question block releases a shotgun, even for small Mario. Touch the pickup to acquire it; firing is unavailable before collection, and the world pickup disappears when collected. Fire flowers elsewhere and in the reserve box also appear as shotguns. Mario keeps his regular red-and-blue outfit. Taking damage follows the normal game's power-up rules. The optional source-build flag `./smw --shotgun-start` still starts armed for testing.

The shotgun has unlimited ammunition and a 28-frame pump cycle. A shot instantly hits every hostile sprite in a widening cone up to 96 game pixels ahead of Mario, within the visible playfield. The blast penetrates scenery. It ignores normal fire immunity and includes enemy projectiles and cluster ghosts. Friendly characters, platforms, power-ups, keys and goal objects are preserved.

Effects include original pixel shotgun art, recoil, a muzzle flash, pellet trails, smoke, a tumbling red-and-brass shell, slower, longer-lived red blood particles, screen shake, a synthesized blast, and pump sounds. The muzzle follows facing, ducking and Yoshi poses. Attacks also work while swimming and climbing. Bosses enter their native defeat/exit sequences so the level can continue.

Saves and the app's editable `smw.ini` live in `~/Library/Application Support/SMW Shotgun/`. The source build uses its local `saves/` folder. Transient particles and reload effects clear on reset or snapshot load.

## Source and build

The editable implementation is in `src/shotgun.c`, with hooks in the existing player, sprite, rendering and sound code. It modifies the complete game; this is a native port mod rather than a standalone recreation of one level or an emulator ROM patch.

On this Mac, build tools and SDL2 are already installed. From this directory:

```sh
make -j8
./smw
make test
python3 tools/package_macos.py
```

Elsewhere, install a C compiler, Make and SDL2 development files first. The provided `smw_assets.dat` contains the reconstructed game resources. The native build does not need a ROM once this asset file exists. To extract resources from a separate US game image, use:

```sh
python3 assets/restool.py --rom /absolute/path/to/smw.sfc --no-include-rom
```

The upstream extractor checks the unheadered US image against SHA-1 `6b47bb75d16514b6a476aa0c73a683a2a4c18765`.

## Validation

`make test` runs the real game headlessly with its actual assets, collision tables, PPU and sound engine. It boots through the menus, loads a game level, fires through the Y-button input handler, checks kills and preservation of a shotgun pickup, and captures the animation. It also checks left/right targeting, fire immunity, targets outside the cone, off-screen targets, page crossings, projectiles, cluster sprites, reload/pause gates, player state gates, pixel-buffer bounds and synthesized sound. All seven Koopaling variants have checks for the selected native defeat states.

Screenshots are written to a temporary folder printed by the test; set `SMW_TEST_OUTPUT_DIR` to select an existing destination. The test scene positions enemies deliberately to make the results reproducible. A complete playthrough and every boss cutscene have not been tested.

The separate `tests/record` tool captures the native level's own enemies. Its direct level-load setup initializes the fade-out mosaic state before fading in, and asserts that mosaic pixel grouping is disabled throughout recorded gameplay. This prevents the hill shimmer seen in the first video. Set `SMW_CAPTURE_REFERENCE_RENDERER=1` to record with the slower reference renderer for comparison.

## Provenance and licenses

- Native C base: [snesrev/smw](https://github.com/snesrev/smw), commit `eae20c65c58930c8b62c76188d259579ad4130f1`. The upstream MIT license and dependency notices remain in `LICENSE.txt`.
- Assembly reconstruction: [IsoFrieze/SMWDisX](https://github.com/IsoFrieze/SMWDisX), built as its US version using [Asar 1.91](https://github.com/RPGHacker/asar/tree/v1.91). The reconstructed 524,288-byte image matched the SHA-1 above before resource extraction.
- SDL2 is bundled in the Mac app with its license notice.
- Shotgun art, particle effects and procedural sound are new code in this modification. Super Mario World characters, original graphics, music and level data remain Nintendo's.
