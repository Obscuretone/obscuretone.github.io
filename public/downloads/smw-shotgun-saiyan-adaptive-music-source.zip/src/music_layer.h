#pragma once
#include "types.h"
/* These transient audio voices follow the native music parser, never SFX. */
typedef struct MusicString {
  double line[1024], delay, previous, age, release, velocity;
  unsigned write;
  bool gate, active;
} MusicString;
typedef struct MusicLayer {
  MusicString voices[2];
  float samples[534*2];
  double gain, filtered[2];
  unsigned random, notes;
  int mode;
  bool paused;
} MusicLayer;
void MusicLayer_Reset(MusicLayer *s);
void MusicLayer_SetMode(MusicLayer *s,int mode);
void MusicLayer_NoteOn(MusicLayer *s,int channel,double midi,double velocity);
void MusicLayer_KeyOff(MusicLayer *s,unsigned mask);
void MusicLayer_Sample(MusicLayer *s,int offset);
void MusicLayer_Mix(MusicLayer *s,int16 *pcm,int frames);
