/* A second, note-synchronous instrument above the unmodified native soundtrack. */
#include "music_layer.h"
#include <math.h>
#include <string.h>
static const double tau=6.283185307179586;
void MusicLayer_Reset(MusicLayer *s){memset(s,0,sizeof(*s));s->random=0x48ab317;}
void MusicLayer_SetMode(MusicLayer *s,int mode){
  s->paused=mode<0;
  if(mode<0)return;
  if(mode!=s->mode)s->gain=0;
  s->mode=mode;
  if(!mode){s->gain=0;s->filtered[0]=s->filtered[1]=0;}
}
static double Noise(MusicLayer *s){
  s->random^=s->random<<13;s->random^=s->random>>17;s->random^=s->random<<5;
  return ((int)(s->random&65535)-32768)/32768.0;
}
void MusicLayer_NoteOn(MusicLayer *s,int channel,double midi,double velocity){
  if(channel<0 || channel>1 || s->paused)return;
  /* Keep a real guitar register; octave folding preserves the song's key. */
  while(midi<40)midi+=12;
  while(midi>83)midi-=12;
  MusicString *v=&s->voices[channel];
  double hz=440*pow(2,(midi-69)/12.0);
  v->delay=32000/hz-0.5;v->write=0;v->previous=0;
  v->age=0;v->release=1;v->velocity=velocity;v->gate=v->active=true;
  for(int i=0;i<1024;++i){
    double p=tau*i/(v->delay+0.5);
    v->line[i]=0.32*Noise(s)+0.45*sin(p)+0.18*sin(2*p)+0.08*sin(3*p);
  }
  ++s->notes;
}
void MusicLayer_KeyOff(MusicLayer *s,unsigned mask){
  for(int i=0;i<2;++i)if(mask&(1u<<i))s->voices[i].gate=false;
}
static double ReadString(MusicString *v,double delay){
  double at=v->write-delay;while(at<0)at+=1024;
  unsigned i=(unsigned)at;double f=at-i;
  return v->line[i&1023]*(1-f)+v->line[(i+1)&1023]*f;
}
void MusicLayer_Sample(MusicLayer *s,int offset){
  if(offset<0 || offset>=534)return;
  if(s->paused){s->samples[offset*2]=s->samples[offset*2+1]=0;return;}
  s->gain+=(1-s->gain)*0.0009;
  double mix[2]={0,0};
  for(int i=0;i<2;++i){
    MusicString *v=&s->voices[i];if(!v->active)continue;
    double y=ReadString(v,v->delay);
    v->line[v->write]=0.9988*(y+v->previous)*0.5;
    v->previous=y;v->write=(v->write+1)&1023;
    double attack=fmin(1,v->age/0.002);
    if(!v->gate)v->release*=0.9935;
    if(v->release<0.0001)v->active=false;
    double value=tanh(2.9*y)*2900;

    value*=attack*v->release*v->velocity*(i==0?1.0:0.48);
    mix[0]+=value*(i==0?0.82:0.60);mix[1]+=value*(i==0?0.68:0.84);
    v->age+=1.0/32000;
  }
  for(int ch=0;ch<2;++ch){
    s->filtered[ch]+=(mix[ch]-s->filtered[ch])*0.48;
    s->samples[offset*2+ch]=s->mode?s->filtered[ch]*s->gain:0;
  }
}
void MusicLayer_Mix(MusicLayer *s,int16 *pcm,int frames){
  if(frames<=0)return;
  /* Match the native DSP's exact 534-sample block resampling positions. */
  double at=0,step=534.0/frames;
  for(int i=0;i<frames;++i,at+=step)for(int ch=0;ch<2;++ch){
    int value=pcm[i*2+ch]+(int)s->samples[(int)at*2+ch];
    pcm[i*2+ch]=value>32767?32767:value<-32768?-32768:value;
  }
}
