# Super Mario World: Shotgun and Super Saiyan

This release contains a pump-action shotgun and Super Saiyan star power.
Base: snesrev/smw eae20c65c58930c8b62c76188d259579ad4130f1; see LICENSE.txt for MIT license.

Clone the pinned upstream revision, then extract this archive over that checkout,
replacing its corresponding files. This is a source overlay; no patch command is
needed. Install SDL2, a C compiler and Make. Extract your game assets following
SHOTGUN.md, run make -j8, then ./smw. Run make test for the regression suite.
./smw --ki-showcase starts the separate ki practice course.

The shotgun is anchored to the native glove pixels, which remain in front of
the stock. Firing preserves the holding pose through recoil; the muzzle flash
follows the held barrel. Its
pickup emerges behind the source block; the original block face stays visible.
Nine visible pellets advance 12 pixels per frame up to 96 pixels. The six
campaign hits occur four frames after their triggers. A larger red/brass shell
ejects during the pump. Recoil moves Mario backward while the camera stays
steady. Stars grant native gold hair, orange gi and a 12–180-frame charge.
The charge ball stays at his hands and the released wave keeps its diameter.

Build tests/showcase, then ./tests/showcase /absolute/output/folder to record
the six-Rex campaign run and the native transition to the ki practice course,
with three short hits and an eight-Chuck full-charge finish. Output is native
256x224 BGRA at 16000/267 fps, 32kHz stereo s16le and JSONL telemetry.

Star power uses the original Super Mario World star music. Holding the shotgun
adds a distorted single-note electric lead and quiet harmony above low recorded power chords and palm-muted guitar chugs. The lead follows the native melody, while the chords follow the bass part. Their notes and
releases come from the real music parser, so tempo changes and level changes
stay synchronized. Native music and SFX remain intact. Star power, pause,
damage and death suppress the weapon layer. A 0.482 music-only gain matches the combined backing and guitars to the original level music on the calibrated Overworld passage. Native and custom sound effects bypass this trim.


Guitar recordings: D2.wav and D2 PMute.wav by Ax_Grinder (Freesound), CC BY 3.0.
Lead guitar: Dist_sng_G_3rd_str_12th_frt.wav by SpeedY (Freesound), CC0. See MUSIC_CREDITS.txt for all source links and modifications.

The source kit includes that attributed guitar sample data, but no ROM,
extracted Nintendo asset bundle or compiled binaries. Original
Nintendo game graphics, music and level data are not covered by the code's
MIT license. See SHOTGUN.md for provenance and asset extraction.
