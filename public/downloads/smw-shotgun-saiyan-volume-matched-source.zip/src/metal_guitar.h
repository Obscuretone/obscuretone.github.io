#pragma once
#include "types.h"
typedef struct MetalSource {double midi,velocity,seconds;bool valid;} MetalSource;
typedef struct MetalVoice {double pos,step,gain,release,age;bool muted,gate,active;} MetalVoice;
typedef struct MetalGuitar {
  MetalSource sources[8];MetalVoice voices[2];
  double lowest_pitch;int source_channel,root_midi;unsigned next_voice,notes,clock,last_pick;
  bool enabled;
} MetalGuitar;
void MetalGuitar_Reset(MetalGuitar *s);
void MetalGuitar_BeginTrack(MetalGuitar *s);
void MetalGuitar_SetEnabled(MetalGuitar *s,bool enabled);
void MetalGuitar_NoteOn(MetalGuitar *s,int channel,double midi,double velocity,double seconds);
void MetalGuitar_KeyOff(MetalGuitar *s,unsigned mask);
void MetalGuitar_Sample(MetalGuitar *s,double out[2]);
