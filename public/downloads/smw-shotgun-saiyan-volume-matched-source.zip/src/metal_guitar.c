/* Recorded low power chords, driven by the native song's bass part. */
#include "metal_guitar.h"
#include "power_chord_samples.h"
#include <math.h>
#include <string.h>
void MetalGuitar_BeginTrack(MetalGuitar *s){
  memset(s->sources,0,sizeof(s->sources));memset(s->voices,0,sizeof(s->voices));
  s->source_channel=-1;s->lowest_pitch=128;s->root_midi=36;s->next_voice=0;s->last_pick=~0u;
}
void MetalGuitar_Reset(MetalGuitar *s){memset(s,0,sizeof(*s));MetalGuitar_BeginTrack(s);}
static void Pick(MetalGuitar *s,MetalSource *note,bool accent){
  int pitch_class=((int)floor(note->midi+0.5))%12;
  /* Drop-B through Bb2: the accompaniment stays on the low strings. */
  s->root_midi=pitch_class==11?35:36+pitch_class;
  unsigned index;
  if(s->last_pick==s->clock)index=(s->next_voice-1)&1;
  else{index=s->next_voice++&1;for(int i=0;i<2;++i)s->voices[i].gate=false;++s->notes;}
  s->last_pick=s->clock;
  MetalVoice *v=&s->voices[index];memset(v,0,sizeof(*v));
  v->muted=!accent && note->seconds<0.20;v->gate=v->active=true;v->release=1;
  v->step=pow(2,(s->root_midi-kPowerChordRootMidi)/12.0);
  v->gain=0.9*pow(fmin(1,fmax(0,note->velocity)),0.3);
}
void MetalGuitar_SetEnabled(MetalGuitar *s,bool enabled){
  if(s->enabled==enabled)return;s->enabled=enabled;
  memset(s->voices,0,sizeof(s->voices));
  if(enabled && s->source_channel>=0 && s->sources[s->source_channel].valid)
    Pick(s,&s->sources[s->source_channel],true);
}
void MetalGuitar_NoteOn(MetalGuitar *s,int channel,double midi,double velocity,double seconds){
  if(channel<0 || channel>=8)return;
  MetalSource *note=&s->sources[channel];*note=(MetalSource){midi,velocity,seconds,true};
  /* Keep the lowest-register part as the harmonic source. Melody changes do
     not send the rhythm guitar jumping through high single-note figures. */
  if(s->source_channel<0 || midi<s->lowest_pitch-0.5){s->source_channel=channel;s->lowest_pitch=midi;}
  else if(channel==s->source_channel)s->lowest_pitch=fmin(s->lowest_pitch,midi);
  if(s->enabled && channel==s->source_channel)Pick(s,note,false);
}
void MetalGuitar_KeyOff(MetalGuitar *s,unsigned mask){
  if(s->source_channel>=0 && (mask&(1u<<s->source_channel)))
    for(int i=0;i<2;++i)s->voices[i].gate=false;
}
static double Read(const int16 *pcm,int count,double pos){
  int i=(int)pos;if(i<0 || i>=count-1)return 0;
  double f=pos-i;return (pcm[i]*(1-f)+pcm[i+1]*f)/32768.0;
}
void MetalGuitar_Sample(MetalGuitar *s,double out[2]){
  out[0]=out[1]=0;++s->clock;if(!s->enabled)return;
  for(int i=0;i<2;++i){MetalVoice *v=&s->voices[i];if(!v->active)continue;
    const int16 *pcm=v->muted?kPowerChordMuted:kPowerChordOpen;
    int n=v->muted?sizeof(kPowerChordMuted)/sizeof(int16):sizeof(kPowerChordOpen)/sizeof(int16);
    if(v->pos>=n-1 || v->release<0.0001){v->active=false;continue;}
    if(!v->gate)v->release*=0.996;
    double env=fmin(1,v->age/0.0015)*v->gain*v->release;
    /* The recording already contains the real amp/cabinet and root/fifth/
       octave voicing. A tiny stereo offset gives it width without a lead. */
    out[0]+=Read(pcm,n,v->pos)*env*7600;
    out[1]+=Read(pcm,n,v->pos*1.0018+40)*env*7600;
    v->pos+=v->step;v->age+=1.0/kPowerChordSampleRate;
  }
}
