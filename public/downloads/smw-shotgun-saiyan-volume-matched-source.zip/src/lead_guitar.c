/* Single-note distorted electric guitar for the native melody and harmony.
   The low power-chord guitar has its own bass source and separate voices. */
#include "lead_guitar.h"
#include "lead_guitar_sample.h"
#include <math.h>
#include <string.h>

void LeadGuitar_BeginTrack(LeadGuitar *s) {
  memset(s->source, 0, sizeof(s->source));
  memset(s->voice, 0, sizeof(s->voice));
  s->next[0] = s->next[1] = 0;
}

void LeadGuitar_Reset(LeadGuitar *s) {
  memset(s, 0, sizeof(*s));
}

static void Pick(LeadGuitar *s, int channel) {
  LeadGuitarNote *note = &s->source[channel];
  for (int i = channel * 2; i < channel * 2 + 2; ++i)
    s->voice[i].gate = false;
  LeadGuitarVoice *v = &s->voice[channel * 2 + (s->next[channel]++ & 1)];
  memset(v, 0, sizeof(*v));
  double midi = note->midi;
  while (midi < 48) midi += 12;
  while (midi > 84) midi -= 12;
  v->channel = channel;
  v->step = pow(2, (midi - kLeadGuitarSampleMidi) / 12.0);
  v->gain = 0.94 * pow(fmin(1, fmax(0, note->velocity)), 0.4);
  if (channel == 1) v->gain *= 0.38;
  v->release = 1;
  v->gate = v->active = true;
  s->last_midi = midi;
  ++s->notes;
}

void LeadGuitar_SetEnabled(LeadGuitar *s, bool enabled) {
  if (s->enabled == enabled) return;
  s->enabled = enabled;
  memset(s->voice, 0, sizeof(s->voice));
  if (enabled)
    for (int channel = 0; channel < 2; ++channel)
      if (s->source[channel].held) Pick(s, channel);
}

void LeadGuitar_NoteOn(LeadGuitar *s, int channel, double midi, double velocity) {
  if (channel < 0 || channel > 1) return;
  s->source[channel] = (LeadGuitarNote){midi, velocity, true};
  if (s->enabled) Pick(s, channel);
}

void LeadGuitar_KeyOff(LeadGuitar *s, unsigned mask) {
  for (int channel = 0; channel < 2; ++channel) {
    if (!(mask & (1u << channel))) continue;
    s->source[channel].held = false;
    for (int i = channel * 2; i < channel * 2 + 2; ++i)
      s->voice[i].gate = false;
  }
}

void LeadGuitar_Sample(LeadGuitar *s, double out[2]) {
  out[0] = out[1] = 0;
  if (!s->enabled) return;
  const int count = sizeof(kLeadGuitarSample) / sizeof(kLeadGuitarSample[0]);
  for (int i = 0; i < 4; ++i) {
    LeadGuitarVoice *v = &s->voice[i];
    if (!v->active) continue;
    int at = (int)v->position;
    if (at >= count - 1 || v->release < 0.0001) {
      v->active = false;
      continue;
    }
    if (!v->gate) v->release *= 0.995;
    double fraction = v->position - at;
    double value = (kLeadGuitarSample[at] * (1 - fraction) +
                    kLeadGuitarSample[at + 1] * fraction) / 32768.0;
    value *= fmin(1, v->age / 0.0015) * v->gain * v->release * 8000;
    out[0] += value * (v->channel == 0 ? 0.94 : 0.68);
    out[1] += value * (v->channel == 0 ? 0.90 : 0.88);
    v->position += v->step;
    v->age += 1.0 / 32000;
  }
}
