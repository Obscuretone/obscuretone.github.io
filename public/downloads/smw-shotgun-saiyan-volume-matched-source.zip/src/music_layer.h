#pragma once
#include "types.h"
#include "metal_guitar.h"
#include "lead_guitar.h"
/* These transient audio voices follow the native music parser, never SFX. */
typedef struct MusicString {
  double line[1024], delay, previous, age, release, velocity;
  unsigned write;
  bool gate, active;
} MusicString;
typedef struct MusicLayer {
  MusicString voices[2];
  MetalGuitar guitar;
  LeadGuitar lead;
  float samples[534*2];
  double gain, filtered[2];
  unsigned random, notes;
  int mode;
  bool paused;
} MusicLayer;
void MusicLayer_Reset(MusicLayer *s);
void MusicLayer_BeginTrack(MusicLayer *s);
void MusicLayer_SetMode(MusicLayer *s,int mode);
void MusicLayer_NoteOn(MusicLayer *s,int channel,double midi,double velocity,double seconds);
void MusicLayer_KeyOff(MusicLayer *s,unsigned mask);
void MusicLayer_Sample(MusicLayer *s,int offset);
void MusicLayer_Mix(MusicLayer *s,int16 *pcm,int frames);

/* Level-match the complete armed music bus, never sound effects. */
double MusicLayer_MusicGain(const MusicLayer *s);
