# Super Mario World shotgun modification

Base: snesrev/smw commit eae20c65c58930c8b62c76188d259579ad4130f1 (MIT).
Clone that revision, extract this kit into it and run `git apply shotgun.patch`.
Install SDL2, a C compiler and Make. Follow SHOTGUN.md for game resource extraction.
Run `make -j8`, then `./smw --shotgun-start`. `make test` runs the integration suite.
`make tests/record` builds the continuous gameplay recorder.
`./tests/record /absolute/output/directory` writes game.bgra, game.s16le and events.jsonl.
Video is 256x224 BGRA at 16000/267 fps; audio is 32 kHz stereo s16le.
The latest version uses a 96-pixel range, a lowered gun and regular Mario colors.
The recorder waits 36 visible frames before firing and approaches to within 80 pixels.
No game ROM or extracted game asset bundle is included.
The latest recorder makes three planned jumps: Dragon Coin, flying question block and raised terrain.
Collection is logged from the real in-game Dragon Coin counter.
The level shortcut uploads the level SPC bank and starts the header-selected music.
The recorder logs the actual music track and flying-block activation state.
