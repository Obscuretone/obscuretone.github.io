/* Shotgun mod for snesrev/smw. Original pixel art and synthesized sound. */
#include "shotgun.h"
#include "smw_rtl.h"
#include "variables.h"
#include "funcs.h"
#include <math.h>
#include <stdatomic.h>
#include <string.h>

enum { kRange = 96, kCooldown = 28, kParticleCount = 384 };
enum { kBlood, kSmoke, kPellet, kShell };
typedef struct Particle {
  float x, y, vx, vy;
  uint8 life, kind, size;
  uint32 color;
} Particle;
static Particle particles[kParticleCount];
static unsigned particle_cursor, random_state = 0x51a7f00d;
static int cooldown, flash, shot_x, shot_y, shot_dir, shot_origin_x, last_mode;
static bool start_armed, reserve_drawn;
static struct { int x, y; } pickups[12];
static int pickup_count;
static atomic_uint sound_event;

static unsigned Random(void) {
  random_state ^= random_state << 13;
  random_state ^= random_state >> 17;
  random_state ^= random_state << 5;
  return random_state;
}
static void Emit(float x, float y, float vx, float vy, int kind, int life, uint32 color, int size) {
  Particle *p = &particles[particle_cursor++ % kParticleCount];
  *p = (Particle){x, y, vx, vy, life, kind, size, color};
}
void ShotgunSetStartArmed(bool armed) { start_armed = armed; }
void ShotgunReset(void) {
  memset(particles, 0, sizeof(particles));
  particle_cursor = cooldown = flash = pickup_count = 0;
  reserve_drawn = false;
  last_mode = -1;
  atomic_store(&sound_event, 0);
}
void ShotgunRegisterPickup(int x, int y) {
  if (pickup_count < 12) {
    pickups[pickup_count].x = x;
    pickups[pickup_count++].y = y;
  }
}
void ShotgunRegisterReserve(void) { reserve_drawn = true; }

static bool InLevel(void) { return misc_game_mode == 0x14; }
static int PlayerGunY(void) {
  return (int)player_ypos + (player_ducking_flag ? 27 : 21) +
      (player_riding_yoshi_flag ? (yoshi_ducking_flag ? 12 : 4) : 0);
}
void ShotgunTick(void) {
  pickup_count = 0;
  reserve_drawn = false;
  if (!InLevel()) {
    memset(particles, 0, sizeof(particles));
    cooldown = flash = 0;
  } else {
    if (last_mode != 0x14 && start_armed)
      player_current_power_up = 3;
    if (!flag_sprites_locked && !flag_pause) {
      if (cooldown) --cooldown;
      if (flash) --flash;
      for (unsigned i = 0; i < kParticleCount; ++i) {
        Particle *p = &particles[i];
        if (!p->life) continue;
        --p->life;
        p->x += p->vx;
        p->y += p->vy;
        if (p->kind == kBlood || p->kind == kShell) p->vy += 0.16f;
        if (p->kind == kSmoke) { p->vx *= 0.95f; p->vy -= 0.012f; }
      }
    }
  }
  last_mode = misc_game_mode;
}

/* Explicit hostile IDs: platforms, Yoshi, dolphins, keys and goal objects survive. */
static bool IsHostile(unsigned id) {
  if (id <= 0x18) return id != 0x0e && id != 0x12;
  if (id >= 0x1a && id <= 0x20) return true;
  if (id >= 0x22 && id <= 0x2b) return true;
  if (id >= 0x30 && id <= 0x34) return true;
  if (id >= 0x37 && id <= 0x3d) return true;
  if (id == 0x2e || id == 0x3f || id == 0x40 || id == 0x44) return true;
  if (id >= 0x46 && id <= 0x48) return true;
  if (id >= 0x4b && id <= 0x51) return true;
  if (id >= 0x64 && id <= 0x68) return true;
  if (id >= 0x6e && id <= 0x73) return true;
  if (id == 0x86 || id == 0x90) return true;
  if (id >= 0x91 && id <= 0x9b) return true;
  if (id >= 0x9d && id <= 0xb0) return true;
  if (id >= 0xb2 && id <= 0xb6) return true;
  return id == 0xbc || id == 0xbd || id == 0xbe || id == 0xbf ||
         id == 0xc2 || id == 0xc3 || id == 0xc5;
}

static bool HitBox(int x, int y, int w, int h) {
  /* All calculations use signed wrapped world deltas, including page crossings. */
  int dx = (int16)(x - shot_origin_x), dy = (int16)(y - shot_y);
  int near = shot_dir > 0 ? dx : -dx - w;
  int far = near + w;
  if (far < 0 || near > kRange) return false;
  int spread = 10 + (far < kRange ? far : kRange) / 5;
  return dy <= spread && dy + h >= -spread;
}
static bool VisibleBox(int x, int y, int w, int h) {
  int sx = (int16)(x - mirror_current_layer1_xpos);
  int sy = (int16)(y - mirror_current_layer1_ypos);
  return sx + w >= 0 && sx < 256 && sy + h >= 32 && sy < 224;
}
static void BloodBurst(int x, int y) {
  static const uint32 colors[] = {0xf03438, 0xc51f2f, 0x951625, 0x6a1624};
  for (int n = 0; n < 24; ++n) {
    float speed = 0.4f + (Random() & 63) * 0.045f;
    float vy = ((int)(Random() % 100) - 75) * 0.045f;
    Emit(x, y, shot_dir * speed, vy, kBlood, 48 + Random() % 36,
         colors[n & 3], n < 7 ? 2 : 1);
  }
  for (int n = 0; n < 4; ++n)
    Emit(x, y, shot_dir * (1 + n * 0.5f), -1.0f, kSmoke, 18, 0xd2c4b0, 2);
}

static bool BossDying(int k) {
  unsigned id = spr_spriteid[k];
  if (id == 0xa0) return spr_table151c[k] >= 4 && spr_table151c[k] <= 6;
  if (id == 0xa9) return spr_table151c[k] != 0;
  if (id == 0xc5) return spr_table00c2[k] == 6;
  if (id == 0x29) {
    if (spr_table00c2[k] >= 5) return spr_table151c[k] >= 5;
    if (spr_table00c2[k] >= 3) return spr_decrementing_table163e[k] != 0;
    return spr_table151c[k] >= 4;
  }
  return false;
}
static void Defeat(int k) {
  unsigned id = spr_spriteid[k];
  if (id == 0xa0) {
    /* Use Bowser's final defeat sequence so Peach and the ending still run. */
    spr_table151c[k] = 4;
    spr_yspeed[k] = (uint8)-32;
    spr_xspeed[k] = 0;
    spr_decrementing_table1540[k] = 0;
  } else if (id == 0xa9) {
    spr_table151c[k] = 1;
    spr_current_status[k] = 2;
    spr_yspeed[k] = (uint8)-48;
  } else if (id == 0xc5) {
    spr_table00c2[k] = 6;
    spr_decrementing_table1540[k] = 0;
  } else if (id == 0x29) {
    /* Koopalings have three different engines. Let their own exit logic run. */
    if (spr_table00c2[k] >= 5 && spr_table1570[k]) {
      spr_current_status[k] = 0; /* Lemmy/Wendy decoy. */
    } else if (spr_table00c2[k] >= 5) {
      spr_table151c[k] = 5;
      spr_yspeed[k] = 0;
    } else if (spr_table00c2[k] < 3) {
      spr_table151c[k] = 4;
      spr_decrementing_table1540[k] = 19;
    } else {
      spr_decrementing_table163e[k] = 80; /* Iggy/Larry's native exit timer. */
    }
  } else {
    spr_current_status[k] = 0;
    /* Keep this instance dead when the camera moves away and returns. */
    if (spr_load_status_table_index[k] != 0xff)
      sprites_load_status[spr_load_status_table_index[k]] = 1;
  }
}

bool ShotgunFire(void) {
  if (!InLevel() || player_current_power_up != 3 || player_current_state ||
      flag_sprites_locked || flag_pause || cooldown) return false;
  cooldown = kCooldown;
  flash = 6;
  shot_dir = player_facing_direction ? 1 : -1;
  shot_origin_x = player_xpos + 8;
  shot_x = shot_origin_x + shot_dir * 22;
  shot_y = PlayerGunY();
  timer_display_player_shoot_fireball_pose = 12;
  player_xspeed = (uint8)(-shot_dir * 18);
  timer_shake_layer1 = 5;
  atomic_fetch_add(&sound_event, 1);
  for (int n = 0; n < 9; ++n)
    Emit(shot_x, shot_y, shot_dir * (13.0f + (Random() & 7)), (n - 4) * 0.65f,
         kPellet, 12, n & 1 ? 0xffde93 : 0xfff6d2, 1);
  Emit(shot_x - shot_dir * 13, shot_y - 2, -shot_dir * 1.8f, -3.2f,
       kShell, 44, 0xd93931, 2);
  for (int n = 0; n < 8; ++n)
    Emit(shot_x, shot_y, shot_dir * (0.5f + n * 0.2f), -0.4f - n * 0.1f,
         kSmoke, 16 + n, 0xc4bfb2, 2);

  for (int k = 0; k < 12; ++k) {
    if (spr_current_status[k] < 8 || spr_current_status[k] > 10 ||
        !IsHostile(spr_spriteid[k]) || BossDying(k)) continue;
    if (spr_spriteid[k] == 0x9d && spr_table00c2[k] == 3) continue;
    CollInfo ci = {0};
    StandardSpriteToSpriteCollisionChecks_GetSpriteClippingA(k, &ci);
    int x = PAIR16(ci.r10, ci.r4), y = PAIR16(ci.r11, ci.r5);
    if (!VisibleBox(x, y, ci.r6, ci.r7) || !HitBox(x, y, ci.r6, ci.r7)) continue;
    BloodBurst(x + ci.r6 / 2, y + ci.r7 / 2);
    Defeat(k);
  }
  for (int k = 0; k < 10; ++k) {
    int id = ext_spr_spriteid[k];
    if (!(id == 2 || id == 3 || id == 4 || id == 6 || id == 11 || id == 12 || id == 13)) continue;
    int x = PAIR16(ext_spr_xpos_hi[k], ext_spr_xpos_lo[k]);
    int y = PAIR16(ext_spr_ypos_hi[k], ext_spr_ypos_lo[k]);
    if (VisibleBox(x, y, 8, 8) && HitBox(x, y, 8, 8)) {
      BloodBurst(x + 4, y + 4);
      ext_spr_spriteid[k] = 0;
    }
  }
  for (int k = 0; k < 20; ++k) {
    int id = cluster_spr_spriteid[k];
    if (!(id == 3 || id == 4 || id == 6 || id == 7 || id == 8)) continue;
    int x = PAIR16(cluster_spr_xpos_hi[k], cluster_spr_xpos_lo[k]);
    int y = PAIR16(cluster_spr_ypos_hi[k], cluster_spr_ypos_lo[k]);
    if (VisibleBox(x, y, 16, 16) && HitBox(x, y, 16, 16)) {
      BloodBurst(x + 8, y + 8);
      cluster_spr_spriteid[k] = 0;
    }
  }
  return true;
}

typedef struct Canvas { uint8 *p; size_t pitch; int w, h, top; } Canvas;
static void Rect(Canvas c, int x, int y, int w, int h, uint32 rgb) {
  for (int yy = y; yy < y + h; ++yy) {
    if (yy < c.top || yy >= c.h) continue;
    for (int xx = x; xx < x + w; ++xx) {
      if (xx < 0 || xx >= c.w) continue;
      uint32 color = 0xff000000u | rgb;
      memcpy(c.p + yy * c.pitch + xx * 4, &color, 4);
    }
  }
}
static void Gun(Canvas c, int x, int y, int dir, int recoil) {
  /* 23 by 9, drawn in local pixels so facing and recoil stay crisp. */
  static const char *art[] = {
    "         oooooooooooooo",
    "   oooooossssssssssssooo",
    "ooottttttgggggggggggggo",
    "ottttttttgggggggggggggo",
    "ottttttoooowwwwwwwooooo",
    " ootttoo  obboooooo     ",
    "  oooo    obbo          ",
    "          oo           "
  };
  for (int row = 0; row < 8; ++row) {
    for (int col = 0; art[row][col]; ++col) {
      uint32 color;
      switch (art[row][col]) {
      case 'o': color = 0x27202c; break;
      case 's': color = 0xc3c7cd; break;
      case 'g': color = 0x697581; break;
      case 't': color = 0xa65c38; break;
      case 'w': color = 0xd88742; break;
      case 'b': color = 0x70432e; break;
      default: continue;
      }
      Rect(c, x + dir * (col - recoil), y + row - 3, 1, 1, color);
    }
  }
}
void ShotgunDraw(uint8 *pixels, size_t pitch, int width, int height) {
  if (!InLevel()) return;
  Canvas c = {pixels, pitch, width, height, 32};
  int camera_x = mirror_current_layer1_xpos, camera_y = mirror_current_layer1_ypos;
  for (int n = 0; n < pickup_count; ++n)
    Gun(c, pickups[n].x - 3, pickups[n].y + 7, 1, 0);
  if (reserve_drawn) {
    Canvas hud = c; hud.top = 0;
    Gun(hud, 116, 21, 1, 0);
  }
  bool visible = player_current_power_up == 3 && player_current_state != 9 &&
      !player_hide_player_tile_flags && (!timer_player_hurt || (counter_global_frames & 2));
  if (visible) {
    int dir = player_facing_direction ? 1 : -1;
    int x = (int16)(player_xpos - camera_x) + 8 - dir * 3;
    int y = (int16)(PlayerGunY() - camera_y);
    Gun(c, x, y, dir, cooldown > 23 ? 3 : cooldown > 15 ? 1 : 0);
    /* Pump hand slides back during the reload. */
    Rect(c, x + dir * (cooldown > 10 && cooldown < 21 ? 9 : 13), y + 2, 3, 2, 0xffbf90);
  }
  for (unsigned n = 0; n < kParticleCount; ++n) {
    Particle *p = &particles[n];
    if (!p->life) continue;
    int x = (int16)((int)p->x - camera_x), y = (int16)((int)p->y - camera_y);
    if (p->kind == kPellet) {
      Rect(c, x - shot_dir * 3, y, 4, 1, p->color);
    } else if (p->kind == kShell) {
      bool horizontal = (p->life & 4) != 0;
      Rect(c, x, y, horizontal ? 4 : 2, horizontal ? 2 : 4, p->color);
      Rect(c, x, y, 2, 2, 0xf0be55);
    } else {
      Rect(c, x, y, p->size, p->size, p->color);
    }
  }
  if (flash) {
    int x = (int16)(shot_x - camera_x), y = (int16)(shot_y - camera_y);
    int length = flash >= 4 ? 24 : 12;
    for (int i = 0; i < length; ++i) {
      int r = (length - i) / 4 + ((i + flash) % 3);
      Rect(c, x + shot_dir * i, y - r, 1, 2 * r + 1, 0xf58c37);
      if (r > 1) Rect(c, x + shot_dir * i, y - r / 2, 1, r + 1, 0xffe7a0);
      if (i < length / 2) Rect(c, x + shot_dir * i, y - 1, 1, 3, 0xfff9df);
    }
  }
}

void ShotgunMixAudio(int16 *samples, int frames, int channels, int rate) {
  static unsigned seen, noise = 0x7135;
  static int position = -1;
  unsigned event = atomic_load(&sound_event);
  if (event != seen) { seen = event; position = event ? 0 : -1; }
  if (position < 0 || rate <= 0) return;
  for (int i = 0; i < frames; ++i, ++position) {
    float t = (float)position / rate;
    if (t > 0.40f) { position = -1; break; }
    noise ^= noise << 13; noise ^= noise >> 17; noise ^= noise << 5;
    float n = ((int)(noise & 65535) - 32768) / 32768.0f;
    float value = 13500 * n * expf(-t * 38) +
        12500 * sinf(6.2831853f * (90 * t - 70 * t * t)) * expf(-t * 30);
    /* Two brief metallic pump clicks after the initial blast. */
    if (t > 0.19f && t < 0.22f) value += n * 3300 * (0.22f - t) / 0.03f;
    if (t > 0.29f && t < 0.32f) value += n * 4000 * (0.32f - t) / 0.03f;
    for (int ch = 0; ch < channels; ++ch) {
      int v = samples[i * channels + ch] + (int)value;
      samples[i * channels + ch] = v > 32767 ? 32767 : v < -32768 ? -32768 : v;
    }
  }
}
