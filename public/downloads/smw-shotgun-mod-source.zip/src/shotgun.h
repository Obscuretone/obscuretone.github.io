#ifndef SMW_SHOTGUN_H_
#define SMW_SHOTGUN_H_
#include "types.h"
#include <stddef.h>

void ShotgunReset(void);
void ShotgunTick(void);
bool ShotgunFire(void);
void ShotgunDraw(uint8 *pixels, size_t pitch, int width, int height);
void ShotgunMixAudio(int16 *samples, int frames, int channels, int sample_rate);
void ShotgunSetStartArmed(bool armed);
/* Register only power-ups that the original renderer actually drew. */
void ShotgunRegisterPickup(int x, int y);
void ShotgunRegisterReserve(void);
#endif
