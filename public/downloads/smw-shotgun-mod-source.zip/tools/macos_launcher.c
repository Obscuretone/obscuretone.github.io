/* Native Finder launcher: resources stay in the app; saves live in Application Support. */
#include <mach-o/dyld.h>
#include <sys/stat.h>
#include <unistd.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

static void Fail(const char *what) { perror(what); exit(1); }
static void Directory(const char *path) {
  if (mkdir(path, 0755) && errno != EEXIST) Fail(path);
}
static void Copy(const char *source, const char *destination, int only_if_missing) {
  if (only_if_missing && access(destination, F_OK) == 0) return;
  FILE *in = fopen(source, "rb");
  if (!in) Fail(source);
  FILE *out = fopen(destination, "wb");
  if (!out) Fail(destination);
  unsigned char block[16384];
  size_t n;
  while ((n = fread(block, 1, sizeof(block), in)))
    if (fwrite(block, 1, n, out) != n) Fail(destination);
  if (ferror(in) || fclose(out)) Fail(destination);
  fclose(in);
}
int main(void) {
  char executable[PATH_MAX], resolved[PATH_MAX], resources[PATH_MAX];
  char support[PATH_MAX], source[PATH_MAX], destination[PATH_MAX], game[PATH_MAX];
  uint32_t length = sizeof(executable);
  if (_NSGetExecutablePath(executable, &length) || !realpath(executable, resolved)) Fail("App path");
  char *slash = strrchr(resolved, '/');
  if (!slash) return 1;
  *slash = 0;
  snprintf(resources, sizeof(resources), "%s/../Resources", resolved);
  if (!getenv("HOME")) return 1;
  snprintf(support, sizeof(support), "%s/Library", getenv("HOME")); Directory(support);
  snprintf(support, sizeof(support), "%s/Library/Application Support", getenv("HOME")); Directory(support);
  snprintf(support, sizeof(support), "%s/Library/Application Support/SMW Shotgun", getenv("HOME")); Directory(support);
  const char *files[] = {"smw_assets.dat", "smw.ini"};
  for (int i = 0; i < 2; ++i) {
    snprintf(source, sizeof(source), "%s/%s", resources, files[i]);
    snprintf(destination, sizeof(destination), "%s/%s", support, files[i]);
    Copy(source, destination, i == 1);
  }
  if (chdir(support)) Fail(support);
  snprintf(game, sizeof(game), "%s/smw", resources);
  char *args[] = {game, "--shotgun-start", NULL};
  execv(game, args);
  Fail(game);
}
