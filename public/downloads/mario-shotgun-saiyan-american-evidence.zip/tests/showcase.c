/* One native recording: original level, followed by the star-power practice level. */
#define SMW_COMBINED_CAPTURE
#include "record.c"
int main(int argc,char **argv){
  assert(RecordGunMain(argc,argv)==0);
  char p[4096];
  snprintf(p,sizeof(p),"%s/game.bgra",output_dir);video_file=fopen(p,"ab");assert(video_file);
  fseek(video_file,0,SEEK_END);int first=(int)(ftell(video_file)/(256*224*4));
  snprintf(p,sizeof(p),"%s/game.s16le",output_dir);audio_file=fopen(p,"ab");
  snprintf(p,sizeof(p),"%s/events.jsonl",output_dir);events_file=fopen(p,"a");assert(audio_file&&events_file);
  ShotgunSetStartArmed(false);KiWorldSetEnabled(true);
  int phase=-1,start=0,shorts=0,final_hits=0;
  for(int n=0;n<3000;++n){
    unsigned input=0;
    if(phase<0){if(misc_game_mode==0x14&&!(mirror_mosaic_size_and_bgenable&0xf0)&&player_current_power_up==1){phase=0;start=n;}}
    else if(phase==0){input=128;if(timer_star_power){phase=1;start=n;}}
    else if(phase==1){
      input=n-start<18+shorts*3?2:0;
      if(n-start>70){++shorts;phase=shorts<3?2:3;start=n;}
    }else if(phase==2){input=128;int stop=shorts==1?320:512;if(player_xpos>=stop){phase=1;start=n;}}
    else if(phase==3){input=128;if(player_xpos>=928){phase=4;start=n;}}
    else if(phase==4){if(n-start>65){phase=5;start=n;final_hits=KiWaveHits();}}
    else if(phase==5){input=n-start<182?2:0;if(n-start>=176&&n-start<183)input|=1;
      if(n-start>270){phase=6;start=n;}}
    else if(phase==6 && n-start>80)break;
    RecordFrame(input,first+n);
    assert(player_current_state!=9);
    if(n%120==0)printf("KI n=%d phase=%d pos=%u,%u power=%u star=%u charge=%d waves=%d hits=%d\n",n,phase,player_xpos,player_ypos,player_current_power_up,timer_star_power,KiChargeFrames(),KiWaveSerial(),KiWaveHits());
  }
  fclose(video_file);fclose(audio_file);fclose(events_file);
  printf("KI FINAL waves=%d hits=%d power=%d phase=%d\n",KiWaveSerial(),KiWaveHits(),KiWavePower(),phase);
  assert(phase==6 && KiWaveSerial()==4 && KiWaveHits()-final_hits==8 && KiWaveHits()==11 && KiWavePower()==180);
  puts("PASS: public shotgun plus Super Saiyan only; three short waves and eight-Chuck full-charge finish");
  return 0;
}
