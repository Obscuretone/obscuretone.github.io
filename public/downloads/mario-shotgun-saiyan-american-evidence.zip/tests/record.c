/* Record native gameplay, game audio, input and observable enemy removals. */
#define SMW_CAPTURE_MAIN
#include "headless.c"
#include "src/ki.h"
#include "src/ki_world.h"

static FILE *video_file, *audio_file, *events_file;
static int kills, shots, block_hits, acquired_frame = -1;

static void RecordFrame(unsigned input, int n) {
  uint8 status[12], ids[12], block_state[12];
  uint16 xs[12], ys[12];
  for (int k = 0; k < 12; ++k) {
    block_state[k] = spr_table00c2[k];
    status[k] = spr_current_status[k]; ids[k] = spr_spriteid[k];
    xs[k] = GetSprXPos(k); ys[k] = GetSprYPos(k);
  }
  int previous_power = player_current_power_up;
  unsigned previous_serial=ShotgunShotSerial();
  RtlRunFrame(input | (1u << 30));
  if(misc_game_mode==0x14 && !(mirror_mosaic_size_and_bgenable&0xf0))assert(PPU_mosaicSize(g_ppu)==1);
  SmwDrawPpuFrame();
  uint32 pixels[256 * 224];
  memcpy(pixels, g_my_pixels, sizeof(pixels));
  ShotgunDraw((uint8 *)pixels, 1024, 256, 224);
  assert(fwrite(pixels, 1, sizeof(pixels), video_file) == sizeof(pixels));
  /* SMW advances 534 samples at 32 kHz per frame. Keep the captured sound. */
  int16 audio[534 * 2];
  RtlRenderAudio(audio, 534, 2);
  ShotgunMixAudio(audio, 534, 2, 32000);
  assert(fwrite(audio, 1, sizeof(audio), audio_file) == sizeof(audio));
  if (previous_power != 3 && player_current_power_up == 3) {
    bool consumed_pickup = false;
    for (int k = 0; k < 12; ++k)
      if (status[k] && ids[k] == 0x75 && !spr_current_status[k]) consumed_pickup = true;
    assert(consumed_pickup);
    acquired_frame = n;
  }
  bool fired = ShotgunShotSerial()>previous_serial;
  assert(!fired || acquired_frame >= 0);
  if (fired) ++shots;
  fprintf(events_file, "{\"frame\":%d,\"input\":%u,\"x\":%u,\"y\":%u,\"state\":%u,\"power\":%u,\"dragon_coins\":%u,\"air\":%u,\"fired\":%s,\"removed\":[",
      n, input, player_xpos, player_ypos, player_current_state, player_current_power_up, counter_yoshi_coins_collected, player_in_air_flag, fired ? "true" : "false");
  int removed = 0;
  for (int k = 0; k < 12; ++k) {
    if (!(ShotgunHitMask()&(1u<<k)) || status[k] < 8 || status[k] > 10 || spr_current_status[k] != 0) continue;
    int sx = (int16)(xs[k] - mirror_current_layer1_xpos);
    int sy = (int16)(ys[k] - mirror_current_layer1_ypos);
    if (sx < -32 || sx > 256 || sy < 16 || sy > 224) continue;
    fprintf(events_file, "%s{\"slot\":%d,\"sprite_id\":%u,\"x\":%u,\"y\":%u}", removed ? "," : "", k, ids[k], xs[k], ys[k]);
    ++removed; ++kills;
  }
  fprintf(events_file, "],\"flying_blocks\":[");
  int blocks = 0;
  for (int k = 0; k < 12; ++k) {
    if (spr_current_status[k] != 8 || (spr_spriteid[k] != 0x83 && spr_spriteid[k] != 0x84)) continue;
    bool hit = status[k] == 8 && ids[k] == spr_spriteid[k] && !block_state[k] && spr_table00c2[k];
    if (hit) ++block_hits;
    fprintf(events_file, "%s{\"slot\":%d,\"id\":%u,\"x\":%u,\"y\":%u,\"state\":%u,\"hit\":%s}", blocks++ ? "," : "", k, spr_spriteid[k], GetSprXPos(k), GetSprYPos(k), spr_table00c2[k], hit ? "true" : "false");
  }
  fprintf(events_file, "],\"shotgun_pickups\":[");
  int pickups = 0;
  for (int k = 0; k < 12; ++k) {
    if (!spr_current_status[k] || spr_spriteid[k] != 0x75) continue;
    fprintf(events_file, "%s{\"slot\":%d,\"x\":%u,\"y\":%u,\"emerge_timer\":%u}", pickups++ ? "," : "", k, GetSprXPos(k), GetSprYPos(k), spr_decrementing_table1540[k]);
  }
  fprintf(events_file, "],\"acquired_shotgun\":%s,\"music_track\":%u,\"shot_id\":%u,\"pellet_distance\":%d,\"camera_x\":%u,\"camera_y\":%u,\"pose\":%u,\"star\":%u,\"charge\":%d,\"waves\":%d,\"wave_hits\":%d,\"wave_power\":%d,\"ki_world\":%s}\n", acquired_frame == n ? "true" : "false", g_spc_player->port_to_snes[2], ShotgunShotSerial(), ShotgunBlastDistance(), mirror_current_layer1_xpos, mirror_current_layer1_ypos, player_current_pose, timer_star_power, KiChargeFrames(),KiWaveSerial(),KiWaveHits(),KiWavePower(),KiWorldEnabled()?"true":"false");
}
#ifndef SMW_SHOWCASE_CAPTURE
#ifdef SMW_COMBINED_CAPTURE
static int RecordGunMain(int argc,char **argv) {
#else
int main(int argc, char **argv) {
#endif
  assert(argc == 2);
  output_dir = argv[1];
  MkDir(output_dir);
  assert(SDL_Init(0) == 0);
  g_new_ppu = getenv("SMW_CAPTURE_REFERENCE_RENDERER") == NULL;
  g_audio_mutex = SDL_CreateMutex();
  LoadAssets();
  assert(SnesInit(NULL, 0));
  g_snes_width = 256; g_snes_height = 224;
  g_spc_player = SmwSpcPlayer_Create();
  g_spc_player->initialize(g_spc_player);
  PpuBeginDrawing(g_snes->ppu, g_pixels, 1024, 0);
  PpuBeginDrawing(g_my_ppu, g_my_pixels, 1024, 0);
  ShotgunSetStartArmed(false);
  /* Boot the game normally, then request native level 0x105. No placed enemies. */
  for (int n = 0; n < 500; ++n) Frame(n % 100 == 0 ? 0x108 : 0);
  LoadYoshisIsland1();
  assert(misc_game_mode == 0x14 && player_current_power_up == 0);
  char path[4096];
  snprintf(path, sizeof(path), "%s/game.bgra", output_dir); video_file = fopen(path, "wb");
  snprintf(path, sizeof(path), "%s/game.s16le", output_dir); audio_file = fopen(path, "wb");
  snprintf(path, sizeof(path), "%s/events.jsonl", output_dir); events_file = fopen(path, "w");
  assert(video_file && audio_file && events_file);
  int last_trigger = -100, chain_complete = -1, coin_jump = -1, ledge_jump = -1, block_jump = -1, dodge_jump = -1, pickup_jump = -1;
  int visible_since[12], previous_id[12], previous_load[12];
  for (int k = 0; k < 12; ++k) visible_since[k] = previous_id[k] = previous_load[k] = -1;
  for (int n = 0; n < 2600; ++n) {
    unsigned input = n < 40 ? 0 : 128; /* Walk between enemies; press Y only to fire. */
    if (!block_hits && player_current_power_up != 3 && n >= 40) input |= 2;
    bool target_ahead = false;
    for (int k = 0; k < 12; ++k) {
      int sx = (int16)(GetSprXPos(k) - mirror_current_layer1_xpos);
      bool visible = spr_current_status[k] == 8 && sx >= 8 && sx < 240;
      if (!visible || previous_id[k] != spr_spriteid[k] || previous_load[k] != spr_load_status_table_index[k])
        visible_since[k] = -1;
      if (visible && visible_since[k] < 0) visible_since[k] = n;
      previous_id[k] = spr_spriteid[k];
      previous_load[k] = spr_load_status_table_index[k];
      if (!visible || (spr_spriteid[k] != 2 && spr_spriteid[k] != 0xab && spr_spriteid[k] != 0x9f)) continue;
      CollInfo ci = {0};
      StandardSpriteToSpriteCollisionChecks_GetSpriteClippingA(k, &ci);
      int dx = (int16)(PAIR16(ci.r10, ci.r4) - player_xpos);
      int dy = (int16)(PAIR16(ci.r11, ci.r5) - player_ypos);
      /* Let enemies establish themselves on screen, then shoot up close. */
      int far = dx - 8 + ci.r6;
      int spread = 10 + (far < 96 ? far : 96) / 5;
      if (n - visible_since[k] >= 36 && dx > 4 && dx < 80 &&
          dy < 21 + spread - 3 && dy + ci.r7 > 21 - spread + 3)
        target_ahead = true;
    }
    if (player_current_power_up == 3 && n >= 60 && target_ahead && n - last_trigger > 40) {
      input |= 2;
      last_trigger = n;
    }

    /* Unarmed approach: one jump for the coin, then intercept the flying block. */
    if (n >= 40 && n < 62) input |= 1;
    if (coin_jump < 0 && player_xpos >= 188) coin_jump = n;
    if (coin_jump >= 0 && n - coin_jump < 38) input |= 1;
    if (!block_hits && counter_yoshi_coins_collected) {
      bool bill_near = false;
      for (int k = 0; k < 12; ++k) {
        int dx = (int16)(GetSprXPos(k) - player_xpos);
        if (spr_current_status[k] == 8 && spr_spriteid[k] == 0x9f && dx > -72 && dx < 128) bill_near = true;
      }
      for (int k = 0; k < 12; ++k) {
        if (spr_current_status[k] != 8 || spr_spriteid[k] != 0x83) continue;
        int dx = (int16)(GetSprXPos(k) - 8 - player_xpos);
        input = dx > 4 ? 128 : dx < -4 ? 64 : 0;
        if (!player_in_air_flag && dx > -16 && dx < 16 && block_jump < 0) block_jump = n;
      }
      for (int k = 0; k < 12; ++k) {
        int dx = (int16)(GetSprXPos(k) - player_xpos);
        if (!bill_near && dodge_jump < 0 && !player_in_air_flag && spr_current_status[k] == 8 && spr_spriteid[k] == 0xab && dx > 0 && dx < 64) dodge_jump = n;
      }
      if (dodge_jump >= 0 && n - dodge_jump < 30) input |= 1;
      if (block_jump >= 0 && n - block_jump < 18) input |= 1;
      if (bill_near) input = 0;
    }
    if (acquired_frame >= 0) {
      if (ledge_jump < 0 && player_xpos >= 764) ledge_jump = n;
      if (ledge_jump >= 0 && n - ledge_jump < 30) input |= 1;
    }
    if (block_hits && acquired_frame < 0) {
      input = 0;
      for (int k = 0; k < 12; ++k) {
        if (!spr_current_status[k] || spr_spriteid[k] != 0x75) continue;
        int px = GetSprXPos(k);
        if (pickup_jump < 0) {
          if (player_xpos > px - 36) input = 64;
          else if (!player_in_air_flag && spr_decrementing_table1540[k] < 24) pickup_jump = n;
        }
        if (pickup_jump >= 0) {
          if (player_xpos < px - 4) input = 128;
          if (n - pickup_jump < 30) input |= 1;
        }
      }
    }
    if (chain_complete >= 0) input = 0;
    RecordFrame(input, n);
    if (player_current_state == 9) {
      fprintf(stderr, "Died at frame %d x=%u, kills=%d\n", n, player_xpos, kills);
      break;
    }
    if (kills >= 6 && chain_complete < 0) chain_complete = n;
    if (chain_complete >= 0 && n - chain_complete > 100) break;
  }
  fclose(video_file); fclose(audio_file); fclose(events_file);
  printf("Recorded %d observed removals over %d shots; block hits=%d; final x=%u state=%u\n", kills, shots, block_hits, player_xpos, player_current_state);
  return kills >= 6 && shots > 0 && shots <= 6 && counter_yoshi_coins_collected >= 1 &&
      block_hits == 1 && acquired_frame >= 0 && player_current_state != 9 && player_current_power_up == 3 ? 0 : 1;
}
#endif
