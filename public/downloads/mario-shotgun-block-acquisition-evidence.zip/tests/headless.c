/* Uses the actual C game, collision tables, PPU, and asset loader. */
#define SMW_TEST_MAIN
#include "../src/main.c"
#include "src/variables.h"
#include "src/funcs.h"
#include "assets/smw_assets.h"
static const char *output_dir;

static void Frame(uint32 inputs) {
  RtlRunFrame(inputs | (1u << 30));
  SmwDrawPpuFrame();
  int16 audio[534 * 2] = {0};
  RtlRenderAudio(audio, 534, 2);
  ShotgunMixAudio(audio, 534, 2, 32000);
}
static void Screenshot(const char *path) {
  char destination[4096];
  snprintf(destination, sizeof(destination), "%s/%s", output_dir, path);
  uint32 pixels[256 * 224];
  memcpy(pixels, g_my_pixels, sizeof(pixels));
  ShotgunDraw((uint8 *)pixels, 256 * 4, 256, 224);
  for (int i = 0; i < 256 * 224; ++i) pixels[i] |= 0xff000000;
  SDL_Surface *s = SDL_CreateRGBSurfaceFrom(pixels, 256, 224, 32, 1024,
      0xff0000, 0xff00, 0xff, 0xff000000);
  assert(s && SDL_SaveBMP(s, destination) == 0);
  SDL_FreeSurface(s);
}
static void Target(int k, int id, int x, int y) {
  spr_current_status[k] = 8;
  spr_spriteid[k] = id;
  InitializeNormalSpriteRAMTables(k);
  SetSprXYPos(k, x, y);
  spr_load_status_table_index[k] = 0xff;
}
static void CombatTests(void) {
  uint8 saved[sizeof(g_ram)];
  memcpy(saved, g_ram, sizeof(saved));
  ShotgunReset();
  memset(g_ram, 0, sizeof(g_ram));
  misc_game_mode = 0x14;
  player_current_power_up = 3;
  player_facing_direction = 1;
  player_xpos = 40;
  player_ypos = 100;
  Target(0, 0x0f, 96, 100);    /* Goomba ahead */
  Target(1, 0x26, 125, 98);    /* Fire-immune Thwomp */
  Target(2, 0x04, 8, 100);     /* Behind */
  Target(3, 0x35, 112, 100);   /* Yoshi */
  Target(4, 0x75, 130, 100);   /* Power-up */
  Target(5, 0x0f, 110, 12);    /* Above the cone */
  Target(6, 0x0f, 310, 100);   /* Off-screen */
  Target(7, 0x7b, 140, 100);   /* Goal */
  Target(8, 0x41, 180, 100);   /* Dolphin */
  Target(9, 0x0f, 210, 100);   /* Visible, but beyond the shotgun's short range. */
  assert(ShotgunFire());
  assert(!spr_current_status[0] && !spr_current_status[1]);
  for (int k = 2; k <= 9; ++k) assert(spr_current_status[k] == 8);
  assert(!ShotgunFire());
  flag_pause = 1;
  for (int n = 0; n < 60; ++n) ShotgunTick();
  assert(!ShotgunFire());
  flag_pause = 0;
  for (int n = 0; n < 28; ++n) ShotgunTick();
  player_facing_direction = 0;
  assert(ShotgunFire());
  assert(!spr_current_status[2]);
  /* Reload/reset, player state gates, and no effects outside levels. */
  ShotgunReset();
  player_current_state = 9;
  assert(!ShotgunFire());
  player_current_state = 0;
  player_current_power_up = 1;
  assert(!ShotgunFire());
  player_current_power_up = 3;
  flag_sprites_locked = 1;
  assert(!ShotgunFire());
  flag_sprites_locked = 0;
  misc_game_mode = 0x0e;
  assert(!ShotgunFire());
  misc_game_mode = 0x14;
  player_ducking_flag = 1;
  assert(ShotgunFire());
  /* Guard bytes and deliberately unaligned/padded rows exercise clipping. */
  uint8 guarded[32 + 224 * 1033 + 32];
  memset(guarded, 0xa5, sizeof(guarded));
  ShotgunDraw(guarded + 32, 1033, 256, 224);
  for (int i = 0; i < 32; ++i) {
    assert(guarded[i] == 0xa5);
    assert(guarded[sizeof(guarded) - i - 1] == 0xa5);
  }
  for (int y = 0; y < 224; ++y)
    for (int x = 1024; x < 1033; ++x)
      assert(guarded[32 + y * 1033 + x] == 0xa5);
  int16 audio[32000 * 2] = {0};
  ShotgunMixAudio(audio, 32000, 2, 32000);
  int nonzero = 0;
  for (int i = 0; i < 32000 * 2; ++i) nonzero += audio[i] != 0;
  assert(nonzero > 1000);
  assert(audio[31999 * 2] == 0);
  /* World-page crossings, projectiles, cluster enemies and boss exit states. */
  ShotgunReset();
  memset(g_ram, 0, sizeof(g_ram));
  misc_game_mode = 0x14; player_current_power_up = 3;
  player_facing_direction = 1; player_xpos = 250; player_ypos = 100;
  mirror_current_layer1_xpos = 220;
  Target(0, 0x0f, 290, 100);
  ext_spr_spriteid[0] = 4;
  SetHiLo(&ext_spr_xpos_hi[0], &ext_spr_xpos_lo[0], 300);
  SetHiLo(&ext_spr_ypos_hi[0], &ext_spr_ypos_lo[0], 110);
  cluster_spr_spriteid[0] = 4;
  SetHiLo(&cluster_spr_xpos_hi[0], &cluster_spr_xpos_lo[0], 330);
  SetHiLo(&cluster_spr_ypos_hi[0], &cluster_spr_ypos_lo[0], 110);
  assert(ShotgunFire());
  assert(!spr_current_status[0] && !ext_spr_spriteid[0] && !cluster_spr_spriteid[0]);
  for (int type = 0; type < 7; ++type) {
    ShotgunReset();
    Target(0, 0x29, 300, 100);
    spr_table00c2[0] = type;
    spr_table151c[0] = 0;
    spr_table1570[0] = 0;
    spr_decrementing_table163e[0] = 0;
    assert(ShotgunFire());
    if (type < 3) assert(spr_table151c[0] == 4);
    else if (type < 5) assert(spr_decrementing_table163e[0] == 80);
    else assert(spr_table151c[0] == 5);
  }
  memcpy(g_ram, saved, sizeof(saved));
  ShotgunReset();
  puts("PASS: cone, facing, immunity, protected objects, cooldown, pause, state gates, clipping and sound");
}

static void LoadYoshisIsland1(void) {
  /* The normal overworld exit supplies a fully mosaicked fade-out. A direct
     test warp must supply that state too, or the fade-in stops at 2x2 pixels. */
  InitializeFirst8KBOfRAM();
  waiting_for_vblank = 1;
  player_current_life_count = 4;
  misc_game_mode = 0x11;
  misc_intro_level_flag = 5;
  ow_players_map[0] = 1;
  counter_sublevels_entered = 0;
  mirror_mosaic_size_and_bgenable = 0xf0;
  /* The intro-level shortcut skips both normal level-music setup steps. */
  HandleSPCUploads_StrtSPCMscUpld(kSpcLevelMusicBank);
  for (int n = 0; n < 180; ++n) {
    Frame(0);
    if (n == 0) io_music_ch1 = misc_music_register_backup & 0x3f;
  }
  misc_intro_level_flag = 0;
  assert(misc_game_mode == 0x14);
  assert(g_spc_player->port_to_snes[2] == (misc_music_register_backup & 0x3f));
  assert(PPU_mosaicSize(g_ppu) == 1);
  assert((mirror_mosaic_size_and_bgenable & 0xf0) == 0);
  assert(pointer_player_palette == 0xb2c8); /* Regular Mario, even while armed. */
}

static void AcquisitionTests(void) {
  ShotgunSetStartArmed(false);
  LoadYoshisIsland1();
  assert(player_current_power_up == 0 && !ShotgunFire());
  for (int k = 0; k < 12; ++k) spr_current_status[k] = 0;
  Target(0, 0x83, player_xpos + 96, player_ypos - 48);
  spr_table151c[0] = 1; /* The native flower/shotgun variant of the flying block. */
  spr_table00c2[0] = 1;
  spr_decrementing_table1558[0] = 8;
  Spr083_LeftFlyingBlock(0);
  int pickup = misc_scratch7e185e;
  assert(spr_spriteid[pickup] == 0x75 && spr_current_status[pickup]);
  spr_decrementing_table1540[pickup] = 0;
  SprXXX_PowerUps_01C4BF(pickup);
  assert(player_current_power_up == 3 && !spr_current_status[pickup]);
  /* Collection can clear a sprite before its draw routine finishes this tick. */
  ShotgunTick();
  uint32 baseline[256 * 224] = {0}, collected[256 * 224] = {0};
  ShotgunDraw((uint8 *)baseline, 1024, 256, 224);
  PowerUpAndItemDraw(pickup);
  ShotgunDraw((uint8 *)collected, 1024, 256, 224);
  assert(memcmp(baseline, collected, sizeof(baseline)) == 0);
  ShotgunSetStartArmed(true);
  puts("PASS: flying block releases a shotgun for small Mario, collection grants it, no leftover pickup drawing");
}

static void GameplayDemo(void) {
  LoadYoshisIsland1();
  /* Arrange real sprites in a reproducible firing-range scene. */
  for (int k = 0; k < 12; ++k) spr_current_status[k] = 0;
  player_current_power_up = 3;
  player_facing_direction = 1;
  timer_player_hurt = 0;
  ShotgunReset();
  Target(0, 0x0f, player_xpos + 65, player_ypos + 16);
  Target(1, 0x04, player_xpos + 85, player_ypos + 16);
  Target(2, 0x75, player_xpos + 145, player_ypos + 16);
  Frame(0);
  Screenshot("demo-before.bmp");
  Frame(2); /* The actual Y button, through the game's input handler. */
  Frame(0); /* NMI latches controller input for the next game tick. */
  assert(!spr_current_status[0] && !spr_current_status[1]);
  assert(spr_current_status[2] == 8);
  for (int k = 0; k < 10; ++k) assert(ext_spr_spriteid[k] != 5);
  Screenshot("demo-blast.bmp");
  char frames_dir[4096];
  snprintf(frames_dir, sizeof(frames_dir), "%s/frames", output_dir);
  MkDir(frames_dir);
  for (int n = 0; n < 48; ++n) {
    char path[128];
    snprintf(path, sizeof(path), "frames/%03d.bmp", n);
    Screenshot(path);
    Frame(0);
  }
  puts("PASS: native level, Y-button input, kills, power-up replacement, and rendered animation");
}

#ifndef SMW_CAPTURE_MAIN
int main(int argc, char **argv) {
  char scratch[] = "/tmp/smw-shotgun-tests-XXXXXX";
  output_dir = getenv("SMW_TEST_OUTPUT_DIR");
  if (!output_dir) output_dir = mkdtemp(scratch);
  assert(output_dir);
  MkDir(output_dir);
  assert(SDL_Init(0) == 0);
  g_audio_mutex = SDL_CreateMutex();
  MkDir("saves");
  LoadAssets();
  assert(SnesInit(NULL, 0));
  g_snes_width = 256; g_snes_height = 224;
  g_spc_player = SmwSpcPlayer_Create();
  g_spc_player->initialize(g_spc_player);
  PpuBeginDrawing(g_snes->ppu, g_pixels, 1024, 0);
  PpuBeginDrawing(g_my_ppu, g_my_pixels, 1024, 0);
  ShotgunSetStartArmed(true);
  int previous = -1;
  for (int n = 0; n < 5000; ++n) {
    if (misc_game_mode != previous) {
      printf("frame %d mode %02x player (%d,%d) state %d\n", n,
          misc_game_mode, player_xpos, player_ypos, player_current_state);
      previous = misc_game_mode;
    }
    unsigned input = n % 100 == 0 ? 0x108 : 0; /* Start and A */
    if (misc_game_mode == 0x0e) input |= 0x80; /* Walk right from Yoshi's House. */
    Frame(input);
    if (misc_game_mode == 0x14 && !misc_intro_level_flag && player_current_state == 0 && !flag_sprites_locked && n > 500) {
      for (int i = 0; i < 40; ++i) Frame(0);
      assert(player_current_power_up == 3);
      Screenshot("shotgun-idle.bmp");
      CombatTests();
      AcquisitionTests();
      GameplayDemo();
      puts("PASS: game booted through menus into a playable level");
      printf("Screenshots: %s\n", output_dir);
      return 0;
    }
  }
  Screenshot("boot-debug.bmp");
  fprintf(stderr, "Did not reach gameplay (mode %02x)\n", misc_game_mode);
  return 1;
}
#endif
